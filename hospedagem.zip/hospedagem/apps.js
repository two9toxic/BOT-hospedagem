const { StringSelectMenuBuilder, EmbedBuilder, ActionRowBuilder, ApplicationCommandType, ApplicationCommandOptionType, ButtonBuilder, ComponentType, ModalBuilder, TextInputBuilder } = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const auto = new JsonDatabase({ databasePath:"./jsons/autocomplete.json" });
const apps = new JsonDatabase({ databasePath:"./jsons/applications.json" });
const db = new JsonDatabase({ databasePath:"./jsons/produtos.json" });
const perms = new JsonDatabase({ databasePath:"./jsons/perms.json" });
const api = new JsonDatabase({ databasePath:"./jsons/apis.json" });
const fs = require("fs")
const JSZip = require('jszip');
const { SquareCloudAPI } = require('@squarecloud/api');


module.exports = {
    name: "apps",
    description:"Veja todas as suas aplicações",
    type: ApplicationCommandType.ChatInput, 
    run: async(client, interaction) => {
        const teste123 = auto.get(`${interaction.user.id}_owner.owner`)
        if(teste123 !== interaction.user.id) {
            return interaction.reply({content:"❌ | Você não tem acesso, compre um bot para podê usar este comando!", ephemeral:true});
        }
        if( await auto.get(`${interaction.user.id}_owner.butecos`).lenght <= 0){
            interaction.reply({
                embeds:[
                    new EmbedBuilder()
                    .setDescription(`❌ | Você está sem bot ativo...`)
                ],
                ephemeral:true
            })
            return;
        }
        const select = new StringSelectMenuBuilder().setCustomId("appsconfig").setPlaceholder("Selecione a Aplicação.");
        auto.get(`${interaction.user.id}_owner.butecos`).map((buteco) => {
            select.addOptions(
                {
                    label: `${buteco.nome} - ${buteco.idapp}`,
                    description:`${buteco.produto}`,
                    value:`${buteco.idapp}`
                }
            )
        })
        const msg = await interaction.reply({
            embeds:[
                new EmbedBuilder()
                .setAuthor({name: `${interaction.member.displayName} - (${interaction.user.id})`, iconURL: interaction.user.displayAvatarURL()})
            ],
            components:[
                new ActionRowBuilder()
                .addComponents(
                    select
                )
            ]
        }).then(async(msg) => {
            

        const user = interaction.user
        const interação = msg.createMessageComponentCollector({ componentType: ComponentType.StringSelect });
        let ids;
        let produto;
        let nome;
        let vencimento;

        interação.on("collect", async (interaction) => {
            const api1 = new SquareCloudAPI(api.get(`square`));
         if (user.id !== interaction.user.id) {
            interaction.deferUpdate()
           return;
         }
        if(interaction.isStringSelectMenu() && interaction.customId === "appsconfig") {
            interaction.deferUpdate()
            ids = interaction.values[0]
            const application = await api1.applications.get(ids)

            auto.get(`${interaction.user.id}_owner.butecos`).map((buteco) => {
                if(buteco.idapp === ids) {
                    produto = buteco.produto;
                    nome = buteco.nome ;
                    vencimento = buteco.dataExpiracao 
                }
            })
            var timestamp = Math.floor(new Date(vencimento).getTime() / 1000)
                const status = await application.getStatus()
                interaction.message.edit({
                    embeds:[
                        new EmbedBuilder()
                        .setTitle(`${nome} | Aplicação`)
                        .addFields(
                            {
                                name:"💻 | Cpu",
                                value:`\`${status.usage.cpu}\``,
                                inline:true
                            },
                            {
                                name:"🧠 | Memória Ram",
                                value:`\`${status.usage.ram}\``,
                                inline:true
                            },
                            {
                                name:"💾 | SSD",
                                value:`\`${status.usage.storage}\``,
                                inline:true
                            },
                            {
                                name:"🌐 | Network (Total)",
                                value:`\`${status.usage.network.total}\``,
                                inline:true
                            },
                            {
                                name:"🌐 | Network(now)",
                                value:`\`${status.usage.network.now}\``,
                                inline:true
                            },
                            {
                                name:"📨 | Requests",
                                value:`\`${status.requests}\``,
                                inline:true
                            },
                        )
                        .addFields(
                            {
                                name:`${status.status === "running" ? "🟢 | Status" : "🔴 | Status"}`,
                                value:`${status.status === "running" ? "`Em execução`" : "`Está Parado`"}`,
                                inline:true
                            },
                            {
                                name:"⏰ | UpTime",
                                value:`${status.uptimeTimestamp === undefined ? "Bot está Desligado." : `<t:${Math.floor(status.uptimeTimestamp / 1000)}:R>`}`,
                                inline:true
                            },
                            {
                                name:"🕒 | Expira em:",
                                value:`<t:${timestamp}:f> (<t:${timestamp}:R>) `
                            }
                        )
                    ],
                    components:[
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("ligarapp")
                            .setLabel("Ligar")
                            .setStyle(1)
                            .setDisabled(status.status === "running" ? true : false)
                            .setEmoji("⬆"),
                            new ButtonBuilder()
                            .setCustomId("desligarapp")
                            .setLabel("Desligar")
                            .setDisabled(status.status === "running" ? false : true )
                            .setStyle(4)
                            .setEmoji("⬇"),
                            new ButtonBuilder()
                            .setCustomId("reiniciarapp")
                            .setLabel("Reiniciar")
                            .setStyle(2)
                            .setEmoji("🔁"),
                            new ButtonBuilder()
                            .setCustomId("outrasapp")
                            .setLabel("Outras Configurações")
                            .setStyle(2)
                            .setEmoji("⚙"),
                        ),
                        new ActionRowBuilder()
                        .addComponents(select)
                    ]
                })
    
        }
        client.on("interactionCreate", async (interaction) => {
            if(interaction.isButton() && interaction.customId === "outrasapp") {
                interaction.reply({
                    components:[
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("alterarnomeapp")
                            .setLabel("Alterar Nome da Aplicação")
                            .setStyle(3)
                            .setEmoji("✏"),
                            new ButtonBuilder()
                            .setCustomId("alterartokenapp")
                            .setLabel("Alterar token da Aplicação")
                            .setStyle(2)
                            .setEmoji("🛠"),
                            new ButtonBuilder()
                            .setCustomId("transferirposseapp")
                            .setLabel("Alterar Posse da Aplicação")
                            .setStyle(4),
                            new ButtonBuilder()
                            .setCustomId("deletapp")
                            .setLabel("Deletar Aplicação")
                            .setStyle(4),

                        )
                    ],
                    ephemeral:true
                })
            }
            if(interaction.isButton() && interaction.customId === "deletapp") {
                const modal = new ModalBuilder()
                .setCustomId("deleteapp_modal")
                .setTitle("Deletar Aplicação");
                const text = new TextInputBuilder()
                .setCustomId("text")
                .setStyle(1)
                .setLabel(`Coloque: ${nome} Para Deletar`)
                .setPlaceholder("Coloque do jeito que está!");

                modal.addComponents(new ActionRowBuilder().addComponents(text));
                await interaction.showModal(modal);
            }
            if(interaction.isModalSubmit() && interaction.customId === "deleteapp_modal") {
                const text = interaction.fields.getTextInputValue("text");
                if(text !== nome) {
                    interaction.reply({
                        content:`❌ | Coloque o ${nome} da mesma forma!`
                    })
                }
                const userId = interaction.user.id;
                const butecosKey = `${userId}_owner.butecos`;
                const idToMove = ids;
                const application123 = await api1.applications.get(ids)
                application123.delete()
                
                
                const butecosArray = auto.get(butecosKey) || [];
                
                const indexToMove = butecosArray.findIndex(buteco => buteco.idapp === idToMove);
                
                if (indexToMove !== -1) {
                
                    butecosArray.splice(indexToMove, 1);
                
                    auto.set(butecosKey, butecosArray);
                    msg.delete()
                    interaction.update({
                        embeds:[],
                        components:[],
                        content:`Seu Bot foi deletado com sucesso!`
                    })
                }
            }
            if(interaction.isButton() && interaction.customId === "transferirposseapp") {
                const modal = new ModalBuilder()
                .setCustomId("transferirposseapp_modal")
                .setTitle(`${nome} - Transferir Posse`);

                const text = new TextInputBuilder()
                .setCustomId("text")
                .setLabel("Qual é o id do usuario?")
                .setStyle(1)
                .setPlaceholder("LOGO APÓS DE VOCÊ PASSAR A POSSE NÃO TERÁ ACESSO AO BOT!")
                .setRequired(true);

                modal.addComponents(new ActionRowBuilder().addComponents(text));

                await interaction.showModal(modal);
            }
            if(interaction.isModalSubmit() && interaction.customId === "transferirposseapp_modal") {
                const text = interaction.fields.getTextInputValue("text")
                const users = interaction.guild.members.cache.get(text)
                if(!users) {
                    interaction.reply({
                        content:"Eu não achei este usuario, certifique que ele esteja nesse servidor!!",
                        ephemeral:true
                    });
                    return;
                }

                const userId = interaction.user.id;
const butecosKey = `${userId}_owner.butecos`;
const idToMove = ids;


const butecosArray = auto.get(butecosKey) || [];

const indexToMove = butecosArray.findIndex(buteco => buteco.idapp === idToMove);

if (indexToMove !== -1) {
    const objetoMovido = butecosArray[indexToMove];

    butecosArray.splice(indexToMove, 1);

    auto.set(butecosKey, butecosArray);

    const arrayDestino = auto.get(`${text}_owner.butecos`) || [];
    arrayDestino.push(objetoMovido);
    auto.set(`${text}_owner.butecos`, arrayDestino);
    auto.set(`${text}_owner.owner`, `${text}`);
    msg.delete()
    interaction.update({
        embeds:[],
        components:[],
        content:`Seu Bot foi enviado para o usuario: ${users}`
    })
}

            }
            if(interaction.isButton() && interaction.customId === "alterartokenapp") {
                const modal = new ModalBuilder()
                .setCustomId("alterartokenapp_modal")
                .setTitle("Alterar Token do Bot");
                const text = new TextInputBuilder()
                .setCustomId("text")
                .setLabel("Coloque Token Bot")
                .setStyle(1)
                .setRequired(true)
                .setPlaceholder("Coloque o Token Certo!");

                modal.addComponents(new ActionRowBuilder().addComponents(text))
                await interaction.showModal(modal)
            }
            if (interaction.isModalSubmit() && interaction.customId === "alterartokenapp_modal") {
                const msgas = await interaction.reply({
                    content:"Aguarde um momento...",
                    ephemeral:true
                })
                const token = interaction.fields.getTextInputValue("text");
                const data = JSON.stringify({ token: token });
            
                fs.writeFile(`source/client/${token}.json`, data,async  (err) => {
                    if (err) throw err;
                    try{
                        const application123 = await api1.applications.get(ids)
                    application123.commit(`source/client/${token}.json`, 'token.json', true).then(async () => {
                        auto.get(`${interaction.user.id}_owner.butecos`).map((buteco) => {
                            if(buteco.idapp === ids) {
                                produto = buteco.produto;
                                nome = buteco.nome ;
                                vencimento = buteco.dataExpiracao 
                            }
                        })
                        var timestamp = Math.floor(new Date(vencimento).getTime() / 1000)
                            const status = await  application123.getStatus()
                            msg.edit({
                                embeds:[
                                    new EmbedBuilder()
                                    .setTitle(`${nome} | Aplicação`)
                                    .addFields(
                                        {
                                            name:"💻 | Cpu",
                                            value:`\`${status.usage.cpu}\``,
                                            inline:true
                                        },
                                        {
                                            name:"🧠 | Memória Ram",
                                            value:`\`${status.usage.ram}\``,
                                            inline:true
                                        },
                                        {
                                            name:"💾 | SSD",
                                            value:`\`${status.usage.storage}\``,
                                            inline:true
                                        },
                                        {
                                            name:"🌐 | Network (Total)",
                                            value:`\`${status.usage.network.total}\``,
                                            inline:true
                                        },
                                        {
                                            name:"🌐 | Network(now)",
                                            value:`\`${status.usage.network.now}\``,
                                            inline:true
                                        },
                                        {
                                            name:"📨 | Requests",
                                            value:`\`${status.requests}\``,
                                            inline:true
                                        },
                                    )
                                    .addFields(
                                        {
                                            name:`${status.status === "running" ? "🟢 | Status" : "🔴 | Status"}`,
                                            value:`${status.status === "running" ? "`Em execução`" : "`Está Parado`"}`,
                                            inline:true
                                        },
                                        {
                                            name:"⏰ | UpTime",
                                            value:`${status.uptimeTimestamp === undefined ? "Bot está Desligado." : `<t:${Math.floor(status.uptimeTimestamp / 1000)}:R>`}`,
                                            inline:true
                                        },
                                        {
                                            name:"🕒 | Expira em:",
                                            value:`<t:${timestamp}:f> (<t:${timestamp}:R>) `
                                        }
                                    )
                                ],
                                components:[
                                    new ActionRowBuilder()
                                    .addComponents(
                                        new ButtonBuilder()
                                        .setCustomId("ligarapp")
                                        .setLabel("Ligar")
                                        .setStyle(1)
                                        .setDisabled(status.status === "running" ? true : false)
                                        .setEmoji("⬆"),
                                        new ButtonBuilder()
                                        .setCustomId("desligarapp")
                                        .setLabel("Desligar")
                                        .setDisabled(status.status === "running" ? false : true )
                                        .setStyle(4)
                                        .setEmoji("⬇"),
                                        new ButtonBuilder()
                                        .setCustomId("reiniciarapp")
                                        .setLabel("Reiniciar")
                                        .setStyle(2)
                                        .setEmoji("🔁"),
                                        new ButtonBuilder()
                                        .setCustomId("outrasapp")
                                        .setLabel("Outras Configurações")
                                        .setStyle(2)
                                        .setEmoji("⚙"),
                                    ),
                                    new ActionRowBuilder()
                                    .addComponents(select)
                                ]
                            }).then(() => {
                                
                    fs.unlink(`source/client/${token}.json`, (err) => {
                        if (err) throw err;
                        console.log('Token excluído com sucesso!');
                    });
                            })
                            msgas.edit("Agora Sim!")
                    }).catch(() => {
                        msgas.edit("Coloque um token certo!")
                    })

                    } catch (err){
                        console.log(`Ocorreu um Erro: ${err}`)
                        msgas.edit("Ocorreu um erro ao tentar trocar o seu token...")
                    }
                });
            }
            if(interaction.isButton() && interaction.customId === "alterarnomeapp") {

                const modal = new ModalBuilder()
                .setCustomId("alterarnomeapp_modal")
                .setTitle("Alterar Nome da Aplicação");

                const text = new TextInputBuilder()
                .setCustomId("text")
                .setLabel("Qual será o novo nome?")
                .setStyle(1)
                .setPlaceholder("Coloque o nome que ira ser trocado!")
                .setRequired(true);
                 
                modal.addComponents(new ActionRowBuilder().addComponents(text))
                await interaction.showModal(modal)
            }

            if(interaction.isModalSubmit() && interaction.customId === "alterarnomeapp_modal") {
                const text = interaction.fields.getTextInputValue("text");
                interaction.deferUpdate()

                const userId = interaction.user.id;
                const butecosKey = `${userId}_owner.butecos`;
                const idToModify = ids
                const novoValor = text;
                const butecosArray = auto.get(butecosKey) || [];
                const indexToModify = butecosArray.findIndex(buteco => buteco.idapp === idToModify);
                apps.set(`${idToModify}.nome`, `${text}`)
                if (indexToModify !== -1) {
                    butecosArray[indexToModify].nome = novoValor;
                    auto.set(butecosKey, butecosArray);
            const application = await api1.applications.get(ids)

            auto.get(`${interaction.user.id}_owner.butecos`).map((buteco) => {
                if(buteco.idapp === ids) {
                    produto = buteco.produto;
                    nome = buteco.nome ;
                    vencimento = buteco.dataExpiracao 
                }
            })
            var timestamp = Math.floor(new Date(vencimento).getTime() / 1000)
                const status = await application.getStatus()
                msg.edit({
                    embeds:[
                        new EmbedBuilder()
                        .setTitle(`${nome} | Aplicação`)
                        .addFields(
                            {
                                name:"💻 | Cpu",
                                value:`\`${status.usage.cpu}\``,
                                inline:true
                            },
                            {
                                name:"🧠 | Memória Ram",
                                value:`\`${status.usage.ram}\``,
                                inline:true
                            },
                            {
                                name:"💾 | SSD",
                                value:`\`${status.usage.storage}\``,
                                inline:true
                            },
                            {
                                name:"🌐 | Network (Total)",
                                value:`\`${status.usage.network.total}\``,
                                inline:true
                            },
                            {
                                name:"🌐 | Network(now)",
                                value:`\`${status.usage.network.now}\``,
                                inline:true
                            },
                            {
                                name:"📨 | Requests",
                                value:`\`${status.requests}\``,
                                inline:true
                            },
                        )
                        .addFields(
                            {
                                name:`${status.status === "running" ? "🟢 | Status" : "🔴 | Status"}`,
                                value:`${status.status === "running" ? "`Em execução`" : "`Está Parado`"}`,
                                inline:true
                            },
                            {
                                name:"⏰ | UpTime",
                                value:`${status.uptimeTimestamp === undefined ? "Bot está Desligado." : `<t:${Math.floor(status.uptimeTimestamp / 1000)}:R>`}`,
                                inline:true
                            },
                            {
                                name:"🕒 | Expira em:",
                                value:`<t:${timestamp}:f> (<t:${timestamp}:R>) `
                            }
                        )
                    ],
                    components:[
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("ligarapp")
                            .setLabel("Ligar")
                            .setStyle(1)
                            .setDisabled(status.status === "running" ? true : false)
                            .setEmoji("⬆"),
                            new ButtonBuilder()
                            .setCustomId("desligarapp")
                            .setLabel("Desligar")
                            .setDisabled(status.status === "running" ? false : true )
                            .setStyle(4)
                            .setEmoji("⬇"),
                            new ButtonBuilder()
                            .setCustomId("reiniciarapp")
                            .setLabel("Reiniciar")
                            .setStyle(2)
                            .setEmoji("🔁"),
                            new ButtonBuilder()
                            .setCustomId("outrasapp")
                            .setLabel("Outras Configurações")
                            .setStyle(2)
                            .setEmoji("⚙"),
                        ),
                        new ActionRowBuilder()
                        .addComponents(select)
                    ]
                })
                }


            }

            if(interaction.isButton() && interaction.customId === "ligarapp"){
                interaction.deferUpdate()
                const application = await api1.applications.get(ids)
                 await application.start()
                
            var timestamp = Math.floor(new Date(vencimento).getTime() / 1000)
            const status = await application.getStatus()
            try {interaction.message.edit({
                embeds:[
                    new EmbedBuilder()
                    .setTitle(`${nome} | Aplicação`)
                    .addFields(
                        {
                            name:"💻 | Cpu",
                            value:`\`${status.usage.cpu}\``,
                            inline:true
                        },
                        {
                            name:"🧠 | Memória Ram",
                            value:`\`${status.usage.ram}\``,
                            inline:true
                        },
                        {
                            name:"💾 | SSD",
                            value:`\`${status.usage.storage}\``,
                            inline:true
                        },
                        {
                            name:"🌐 | Network (Total)",
                            value:`\`${status.usage.network.total}\``,
                            inline:true
                        },
                        {
                            name:"🌐 | Network(now)",
                            value:`\`${status.usage.network.now}\``,
                            inline:true
                        },
                        {
                            name:"📨 | Requests",
                            value:`\`${status.requests}\``,
                            inline:true
                        },
                    )
                    .addFields(
                        {
                            name:`${status.status === "running" ? "🟢 | Status" : "🔴 | Status"}`,
                            value:`${status.status === "running" ? "`Em execução`" : "`Está Parado`"}`,
                            inline:true
                        },
                        {
                            name:"⏰ | UpTime",
                            value:`${status.uptimeTimestamp === undefined ? "Bot está Desligado." : `<t:${Math.floor(status.uptimeTimestamp / 1000)}:R>`}`,
                            inline:true
                        },
                        {
                            name:"🕒 | Expira em:",
                            value:`<t:${timestamp}:f> (<t:${timestamp}:R>) `
                        }
                    )
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId("ligarapp")
                        .setLabel("Ligar")
                        .setStyle(1)
                        .setDisabled(status.status === "running" ? true : false)
                        .setEmoji("⬆"),
                        new ButtonBuilder()
                        .setCustomId("desligarapp")
                        .setLabel("Desligar")
                        .setDisabled(status.status === "running" ? false : true )
                        .setStyle(4)
                        .setEmoji("⬇"),
                        new ButtonBuilder()
                        .setCustomId("reiniciarapp")
                        .setLabel("Reiniciar")
                        .setStyle(2)
                        .setEmoji("🔁"),
                        new ButtonBuilder()
                        .setCustomId("outrasapp")
                        .setLabel("Outras Configurações")
                        .setStyle(2)
                        .setEmoji("⚙"),
                    ),
                    new ActionRowBuilder()
                    .addComponents(select)
                ]
            })}catch{
                interaction.followUp({
                    content:"Ocorre um erro...",
                    ephemeral:true
                })
            }
            }


            if(interaction.isButton() && interaction.customId === "desligarapp"){
                interaction.deferUpdate()
                const application = await api1.applications.get(ids)
                 await application.stop()
                
            var timestamp = Math.floor(new Date(vencimento).getTime() / 1000)
            const status = await application.getStatus()
            try{interaction.message.edit({
                embeds:[
                    new EmbedBuilder()
                    .setTitle(`${nome} | Aplicação`)
                    .addFields(
                        {
                            name:"💻 | Cpu",
                            value:`\`${status.usage.cpu}\``,
                            inline:true
                        },
                        {
                            name:"🧠 | Memória Ram",
                            value:`\`${status.usage.ram}\``,
                            inline:true
                        },
                        {
                            name:"💾 | SSD",
                            value:`\`${status.usage.storage}\``,
                            inline:true
                        },
                        {
                            name:"🌐 | Network (Total)",
                            value:`\`${status.usage.network.total}\``,
                            inline:true
                        },
                        {
                            name:"🌐 | Network(now)",
                            value:`\`${status.usage.network.now}\``,
                            inline:true
                        },
                        {
                            name:"📨 | Requests",
                            value:`\`${status.requests}\``,
                            inline:true
                        },
                    )
                    .addFields(
                        {
                            name:`${status.status === "running" ? "🟢 | Status" : "🔴 | Status"}`,
                            value:`${status.status === "running" ? "`Em execução`" : "`Está Parado`"}`,
                            inline:true
                        },
                        {
                            name:"⏰ | UpTime",
                            value:`${status.uptimeTimestamp === undefined ? "Bot está Desligado." : `<t:${Math.floor(status.uptimeTimestamp / 1000)}:R>`}`,
                            inline:true
                        },
                        {
                            name:"🕒 | Expira em:",
                            value:`<t:${timestamp}:f> (<t:${timestamp}:R>) `
                        }
                    )
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId("ligarapp")
                        .setLabel("Ligar")
                        .setStyle(1)
                        .setDisabled(status.status === "running" ? true : false)
                        .setEmoji("⬆"),
                        new ButtonBuilder()
                        .setCustomId("desligarapp")
                        .setLabel("Desligar")
                        .setDisabled(status.status === "running" ? false : true )
                        .setStyle(4)
                        .setEmoji("⬇"),
                        new ButtonBuilder()
                        .setCustomId("reiniciarapp")
                        .setLabel("Reiniciar")
                        .setStyle(2)
                        .setEmoji("🔁"),
                        new ButtonBuilder()
                        .setCustomId("outrasapp")
                        .setLabel("Outras Configurações")
                        .setStyle(2)
                        .setEmoji("⚙"),
                    ),
                    new ActionRowBuilder()
                    .addComponents(select)
                ]
            })}catch{
                interaction.followUp({
                    content:"Ocorre um erro...",
                    ephemeral:true
                })
            }

            }


            if(interaction.isButton() && interaction.customId === "reiniciarapp"){
                interaction.deferUpdate()
                try{
                    const application = await api1.applications.get(ids)
                 await application.restart()
            var timestamp = Math.floor(new Date(vencimento).getTime() / 1000)
            const status = await application.getStatus()
            interaction.message.edit({
                embeds:[
                    new EmbedBuilder()
                    .setTitle(`${nome} | Aplicação`)
                    .addFields(
                        {
                            name:"💻 | Cpu",
                            value:`\`${status.usage.cpu}\``,
                            inline:true
                        },
                        {
                            name:"🧠 | Memória Ram",
                            value:`\`${status.usage.ram}\``,
                            inline:true
                        },
                        {
                            name:"💾 | SSD",
                            value:`\`${status.usage.storage}\``,
                            inline:true
                        },
                        {
                            name:"🌐 | Network (Total)",
                            value:`\`${status.usage.network.total}\``,
                            inline:true
                        },
                        {
                            name:"🌐 | Network(now)",
                            value:`\`${status.usage.network.now}\``,
                            inline:true
                        },
                        {
                            name:"📨 | Requests",
                            value:`\`${status.requests}\``,
                            inline:true
                        },
                    )
                    .addFields(
                        {
                            name:`${status.status === "running" ? "🟢 | Status" : "🔴 | Status"}`,
                            value:`${status.status === "running" ? "`Em execução`" : "`Está Parado`"}`,
                            inline:true
                        },
                        {
                            name:"⏰ | UpTime",
                            value:`${status.uptimeTimestamp === undefined ? "Bot está Desligado." : `<t:${Math.floor(status.uptimeTimestamp / 1000)}:R>`}`,
                            inline:true
                        },
                        {
                            name:"🕒 | Expira em:",
                            value:`<t:${timestamp}:f> (<t:${timestamp}:R>) `
                        }
                    )
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId("ligarapp")
                        .setLabel("Ligar")
                        .setStyle(1)
                        .setDisabled(status.status === "running" ? true : false)
                        .setEmoji("⬆"),
                        new ButtonBuilder()
                        .setCustomId("desligarapp")
                        .setLabel("Desligar")
                        .setDisabled(status.status === "running" ? false : true )
                        .setStyle(4)
                        .setEmoji("⬇"),
                        new ButtonBuilder()
                        .setCustomId("reiniciarapp")
                        .setLabel("Reiniciar")
                        .setStyle(2)
                        .setEmoji("🔁"),
                        new ButtonBuilder()
                        .setCustomId("outrasapp")
                        .setLabel("Outras Configurações")
                        .setStyle(2)
                        .setEmoji("⚙"),
                    ),
                    new ActionRowBuilder()
                    .addComponents(select)
                ]
            })
                } catch{
                    interaction.followUp({
                        content:"Ocorre um erro...",
                        ephemeral:true
                    })
                }

            }
         })
        
        })
        } ).catch(() => {
            interaction.reply({
                embeds:[
                    new EmbedBuilder()
                    .setDescription(`❌ | Você está sem bot ativo...`)
                ],
                ephemeral:true
            })
            return;
        });


    }}