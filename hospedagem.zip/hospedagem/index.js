const Discord = require("discord.js")
const config = require('./config.json');
const client = new Discord.Client({
  intents: [
      Discord.GatewayIntentBits.Guilds,
      Discord.GatewayIntentBits.MessageContent,
      Discord.GatewayIntentBits.GuildMessages,
      Discord.GatewayIntentBits.GuildMembers
  ],
  partials: [Discord.Partials.Message, Discord.Partials.Channel]
});

const JSZip = require('jszip');
const path = require('path');
const fs = require("fs");
const {JsonDatabase} = require("wio.db");
const api = new JsonDatabase({databasePath:"./jsons/apis.json"});
const logs = new JsonDatabase({databasePath:"./jsons/logs.json"});
const auto = new JsonDatabase({databasePath:"./jsons/autocomplete.json"});
const db = new JsonDatabase({databasePath:"./jsons/produtos.json"});
const perms = new JsonDatabase({ databasePath:"./jsons/perms.json" });
const db1 = new JsonDatabase({databasePath:"./jsons/carrinhos.json"});
module.exports = client;
const pix = new JsonDatabase({databasePath:"./config.json"});
client.on('interactionCreate', (interaction) => {
    if (interaction.type === Discord.InteractionType.ApplicationCommand) {
        const cmd = client.slashCommands.get(interaction.commandName);
        if (!cmd) return interaction.reply('Error');

        interaction['member'] = interaction.guild.members.cache.get(interaction.user.id);
        cmd.run(client, interaction);
    }
});


const { SquareCloudAPI } = require('@squarecloud/api');
client.on('ready', () => {
    console.log(`櫨 Estou online em ${client.user.username}!`);
});

client.slashCommands = new Discord.Collection();
client.login(config.token);
require('./handler')(client);




const msg = {}

/*===========================================|___CONFIG.JS___|=====================================================*/
client.on("interactionCreate", async(interaction) => {
    if(interaction.isStringSelectMenu() && interaction.customId === "config_select") {
        const options = interaction.values[0]
        if(options === "config_basic"){
            msg[interaction.message.id] = interaction.user.id
            interaction.update({
                components:[
                    new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.StringSelectMenuBuilder()
                        .addOptions(
                            {
                                label:"Alterar Nome",
                                description:"Altere o nome do BOT",
                                value:"alt_nome",
                                emoji:"🪪"
                            },
                            {
                                label:"Alterar Avatar",
                                description:"Altere o avatar do BOT",
                                value:"alt_avatar",
                                emoji:"🖼"
                            },
                            {
                                label:"Configurar LOGS",
                                description:"Configurações sobre as LOGS",
                                value:"config_logs_select",
                                emoji:"<:Termos001:1178362734199455804>"
                            },
                            {
                                label:"Configurar Chaves API",
                                description:"Configurações sobre suas CHAVES APIS",
                                value:"config_api_select",
                                emoji:"🤖"
                            },
                        )
                        .setCustomId("basic_select")
                        .setPlaceholder("Selecione abaixo qual Configurações Basicas deseja fazer")
                    ),
                    new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.ButtonBuilder()
                        .setCustomId("voltar")
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                    )
                ]
            })
        }
        if(options === "config_advanced") {
            msg[interaction.message.id] = interaction.user.id
        
            interaction.update({
                components:[
                    
                    new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.StringSelectMenuBuilder()
                        .addOptions(
                            {
                                label:"Criar Nova Venda",
                                description:"Crie um novo BOT para anúnciar",
                                emoji:"<:blue_botcr:998304667928891482>",
                                value:"create_bot"
                            }
                        )
                        .setCustomId("criar_bot_select")
                        .setPlaceholder("Selecione abaixo qual Configurações avançadas deseja modificar")
                    ),
                    new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.ButtonBuilder()
                        .setCustomId("voltar")
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                    )
                ]
            })
        }
            
    }
    if(interaction.isStringSelectMenu() && interaction.customId === "criar_bot_select") {
        const modal = new Discord.ModalBuilder()
        .setCustomId("modal_criar_bot")
        .setTitle(`${interaction.user.displayName} - New Venda`);

        const text = new Discord.TextInputBuilder()
        .setLabel("Nome do produto (BOT)")
        .setPlaceholder("TICKET|AUTOCONNECT (EXEMPLO)")
        .setRequired(true)
        .setStyle(1)
        .setCustomId("text");

        const text1 = new Discord.TextInputBuilder()
        .setCustomId("text1")
        .setStyle(1)
        .setLabel("Arquivo Principal")
        .setPlaceholder("Exemplo: index.js/ start.js / default.js")
        .setRequired(true)

        modal.addComponents(new Discord.ActionRowBuilder().addComponents(text))
        modal.addComponents(new Discord.ActionRowBuilder().addComponents(text1))
        await interaction.showModal(modal)
    }


if(interaction.isModalSubmit() && interaction.customId === "modal_criar_bot") {
    const nome = interaction.fields.getTextInputValue("text");
    const principal = interaction.fields.getTextInputValue("text1");
    if(db.get(`${nome}.nomeproduto`) === nome) {
        return interaction.reply({content:`⚠ | Já existe este (PRODUTO/BOT)!\n **Caso Queira configura-lo use /configpainel ${nome}`, ephemeral:true})
    }
    const msg = await interaction.update({
        embeds:[
            new Discord.EmbedBuilder()
            .setDescription(`📦 ${interaction.user}, Para concluir a primeira etapa de configuração do seu novo produto, solicitamos que nos envie um arquivo compactado (.ZIP) Contendo seu BOT. Por favor!`)
        ],
        components:[]
    });

    
    const collector = interaction.channel.createMessageCollector({
        filter: m => m.attachments.first() && m.attachments.first().name.endsWith('.zip'),
        max: 1,
    });
    

    collector.on('collect', async (message) => {
        if(message.author.id !== interaction.user.id) return;
        const attachment = message.attachments.first();
        const zip = new JSZip();
        
        
        const data = await fetch(attachment.url).then(res => res.arrayBuffer());
        const zipFile = await zip.loadAsync(data);

        interaction.message.edit({
            embeds:[
                new Discord.EmbedBuilder()
                .setTitle(`⚙ ${interaction.guild.name} | Configurações Avançadas ⚙`)
                .setDescription(`✔ Estamos Verificando os arquivos enviados.`)
            ],
            components:[]
        })
        message.delete()
        if (zipFile.files['package.json'] && (zipFile.files['squarecloud.config'] || zipFile.files['squarecloud.app'])) {
            const packageJson = JSON.parse(await zipFile.file('package.json').async('string'));


            packageJson.main = principal;
            
            zipFile.file('package.json', JSON.stringify(packageJson));

            
            const dir = './source';
            if (!fs.existsSync(dir)){
                fs.mkdirSync(dir);
            }
            fs.writeFileSync(`${dir}/${nome}.zip`, await zipFile.generateAsync({type:"nodebuffer"}))

            auto.push(`produtos`, nome)
            db.set(`${nome}`, {
                nomeproduto: nome,
                preco: {
                    mensal: {
                        onoff: true,
                        preco: 10,
                    },
                    semanal: {
                        onoff:true,
                        preco: 5
                    },
                    quizena: {
                        onoff:true,
                        preco:8.50
                    },
                    embed: {
                        cor: "Default",
                        titulo: `${interaction.guild.name} | ${nome}`,
                        desc:`Para realizar a compra de seu PRODUTO clique abaixo em \`🛒 Realizar Compra\``,
                        banner:null
                    }
                }
            })

            interaction.message.edit({
                embeds:[
                    new Discord.EmbedBuilder()
                    .setTitle(`⚙ ${interaction.guild.name} | Configurações Avançadas ⚙`)
                    .setDescription(`Gostaria de informar que o produto (BOT) de **${nome}** foi criado. Caso seja de seu interesse, por favor, prossiga com a configuração abaixo. \n\n Utilize o comando /configpainel (PRODUTO/BOT) para alterar outras opções.`)
                ],
                components:[
                    new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.ButtonBuilder()
                        .setCustomId("voltar2")
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                    )
                ]
            })
            
            
        } else {
            interaction.message.edit({
                embeds:[
                    new Discord.EmbedBuilder()
                    .setTitle(`⚙ ${interaction.guild.name} | Configurações Avançadas ⚙`)
                    .setDescription(`Não Gostaria de informar que o produto (BOT) de **${nome}**, Verifique se o BOT tenha package.json ou squarecloud.app/squarecloud.config`)
                ],
                components:[
                    new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.ButtonBuilder()
                        .setCustomId("voltar2")
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                    )
                ]
            })
        }
    });
}
if(interaction.isButton() && interaction.customId === "voltar2") {
    interaction.update({
        components:[
            
            new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.StringSelectMenuBuilder()
                .addOptions(
                    {
                        label:"Criar Nova Venda",
                        description:"Crie um novo BOT para anúnciar",
                        emoji:"<:blue_botcr:998304667928891482>",
                        value:"create_bot"
                    }
                )
                .setCustomId("criar_bot_select")
                .setPlaceholder("Selecione abaixo qual Configurações avançadas deseja modificar")
            ),
            new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                .setCustomId("voltar")
                .setLabel("Voltar")
                .setStyle(2)
                .setEmoji("<:voltarkauan:1177188031179010119>")
            )
        ]
    })
}

    if(interaction.isButton() && interaction.customId === "voltar") {
        const a = msg[interaction.message.id];
        if(a !== interaction.user.id) {interaction.deferUpdate() 
            return;}
        interaction.update({
            embeds:[
                new Discord.EmbedBuilder()
                .setTitle(`⚙ ${interaction.guild.name} | Configuração ⚙`)
                .setDescription(`Selectione abaixo qual opção deseja alterar no seu bot. É importante que você preste atenção nas configurações atuais para garantir que suas alterações sejam feitas corretamente. 💥`)
            ],
            components:[
                new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.StringSelectMenuBuilder()
                    .addOptions(
                        {
                            label: `Configurações Basicas`,
                            description:`Configurações sobre sua aplicação`,
                            emoji:"🤖",
                            value:`config_basic`
                        },
                        {
                            label: `Configurações Avançadas`,
                            description:`Configurações sobre seu BOT MENSALIDADE`,
                            value:`config_advanced`,
                            emoji:`<:4323blurpleverifiedbotdeveloper:1178363017096876113>`
                        }
                    )
                    .setPlaceholder("Selecione abaixo qual opção deseja modificar no BOT")
                    .setCustomId("config_select")
                    .setMaxValues(1)
                )
            ]
        })   
    }


    if(interaction.isStringSelectMenu() && interaction.customId === "basic_select") {
        const options = interaction.values[0]
        const a = msg[interaction.message.id];
        if(a !== interaction.user.id) {interaction.deferUpdate() 
            return;}
        if(options === "alt_nome") {
            const user = interaction.guild.members.cache.get(client.user.id)
            const modal = new Discord.ModalBuilder()
            .setCustomId("alt_nome_modal")
            .setTitle("Alterar nome do BOT");
            const text = new Discord.TextInputBuilder()
            .setCustomId("text")
            .setLabel("Qual sera o novo nome do bot?")
            .setValue(`${user.displayName}`)
            .setStyle(1)
            .setPlaceholder("Coloque o nome que você deseja")
            .setRequired(true)

            modal.addComponents(new Discord.ActionRowBuilder().addComponents(text))
            await interaction.showModal(modal)
        }
        if(options === "alt_avatar") {
            const user = interaction.guild.members.cache.get(client.user.id)
            const modal = new Discord.ModalBuilder()
            .setCustomId("alt_vatar_modal")
            .setTitle("Alterar avatar do BOT");
            const text = new Discord.TextInputBuilder()
            .setCustomId("text")
            .setLabel("Qual sera o novo avatar do bot?")
            .setValue(`${user.displayAvatarURL()}`)
            .setStyle(1)
            .setPlaceholder("Coloque a url que você deseja")
            .setRequired(true)

            modal.addComponents(new Discord.ActionRowBuilder().addComponents(text))
            await interaction.showModal(modal)
        }
        if(options === "config_api_select") {
            const square = api.get(`square`)
            const mp = api.get(`mp`)
            
            interaction.update({
                embeds:[
                    new Discord.EmbedBuilder()
                    .setDescription(`Atual ApiKey SquareCloud: ${square === null ? "`Não Definido`" : `||${square}||`} \n Atual Mercado Pago ApiKey: ${mp === null ? "`Não Definido`" : `||${mp}||`}`)
                ],
                components:[
                    new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.StringSelectMenuBuilder()
                        .addOptions(
                            {
                                label:"Alterar Square API Key",
                                emoji:"📦",
                                value:"squareapi"
                            },
                            {
                                label:"Alterar Mercado Pago Api",
                                emoji:"📦",
                                value:"mpapi"
                            }
                        )
                        .setCustomId("api_select_menu")
                        .setPlaceholder("Selecione abaixo")
                    ),
                    new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.ButtonBuilder()
                        .setCustomId("voltar1")
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                    )
                ]
            })

        }
        if(options === "config_logs_select") {
            const renov = interaction.guild.channels.cache.get(logs.get(`renov`))
            const vendas = interaction.guild.channels.cache.get(logs.get(`vendas`))
            const categoria = interaction.guild.channels.cache.get(logs.get(`categoria`))
            const backup = interaction.guild.channels.cache.get(logs.get(`logs_backup`))
            const cliente = interaction.guild.roles.cache.get(logs.get(`cargo_client`))
            interaction.update({
                embeds:[
                    new Discord.EmbedBuilder()
                    .setDescription(`Atual canal de Renovações: ${renov ?? "`Não Definido`"} \nAtual canal de Vendas: ${vendas ?? "`Não Definido`"}\n Atual Categoria de Carrinhos: ${categoria ?? "`Não Definido`"} \n Atual Logs de Backups: ${backup ?? "`Não Definido`"} \n\n Cargo de Cliente: ${cliente ?? "`Não Definido`"}`)
                ],
                components:[
                    new Discord.ActionRowBuilder()
                    .addComponents(
                     new Discord.StringSelectMenuBuilder()
                     .addOptions(
                        {
                            label:"Canal de Renovação",
                            value:"renovec"
                        },
                        {
                            label:"Canal de Vendas",
                            value:"vendascrec"
                        },
                        {
                            label:"Categoria de Carrinho",
                            value:"caterec"
                        },
                        {
                            label:"Logs de Backup's",
                            value:"backuprec"
                        },
                        {
                            label:"Cargo de Cliente",
                            value:"rolescl"
                        }
                     )
                     .setCustomId("logs_select")
                     .setPlaceholder("Selecione Abaixo")
                     .setMaxValues(1)
                    ),
                    new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.ButtonBuilder()
                        .setCustomId("voltar1")
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                    )
                ]
            })
        }
    }
    if(interaction.isStringSelectMenu() && interaction.customId === "logs_select") {
        const options = interaction.values[0]
        const a = msg[interaction.message.id];
        if(a !== interaction.user.id) {interaction.deferUpdate() 
            return;}
        if(options === "renovec") {
            const modal = new Discord.ModalBuilder()
            .setCustomId("renovar_modal")
            .setTitle("Canal de Renovação");

            const text = new Discord.TextInputBuilder()
            .setCustomId("text")
            .setStyle(1)
            .setRequired(true)
            .setPlaceholder("Coloque o id do canal")
            .setLabel("Qual será o canal de Renovação?")

            modal.addComponents(
                new Discord.ActionRowBuilder()
                .addComponents(text)
            );
            await interaction.showModal(modal)
        }
        if(options === "vendascrec") {

            
            const modal = new Discord.ModalBuilder()
            .setCustomId("vendas_modal")
            .setTitle("Canal de Vendas");

            const text = new Discord.TextInputBuilder()
            .setCustomId("text")
            .setStyle(1)
            .setRequired(true)
            .setPlaceholder("Coloque o id do canal")
            .setLabel("Qual será o canal de Vendas?")

            modal.addComponents(
                new Discord.ActionRowBuilder()
                .addComponents(text)
            );
            await interaction.showModal(modal)

        }
        if(options === "caterec") {
            
            const modal = new Discord.ModalBuilder()
            .setCustomId("cat_modal")
            .setTitle("Categoria do Carrinho");

            const text = new Discord.TextInputBuilder()
            .setCustomId("text")
            .setStyle(1)
            .setRequired(true)
            .setPlaceholder("Coloque o id da categoria")
            .setLabel("Qual será a Categoria do carrinho?")

            modal.addComponents(
                new Discord.ActionRowBuilder()
                .addComponents(text)
            );
            await interaction.showModal(modal)
        }
        if(options === "backuprec") {
            
            const modal = new Discord.ModalBuilder()
            .setCustomId("backup_modal")
            .setTitle("Canal de Backup");

            const text = new Discord.TextInputBuilder()
            .setCustomId("text")
            .setStyle(1)
            .setRequired(true)
            .setPlaceholder("Coloque o id do canal")
            .setLabel("Qual será o Canal de Backup?")

            modal.addComponents(
                new Discord.ActionRowBuilder()
                .addComponents(text)
            );
            await interaction.showModal(modal)
        }
        if(options === "rolescl") {
            
            
            const modal = new Discord.ModalBuilder()
            .setCustomId("role_modal")
            .setTitle("Cargo de Cliente");

            const text = new Discord.TextInputBuilder()
            .setCustomId("text")
            .setStyle(1)
            .setRequired(true)
            .setPlaceholder("Coloque o id do cargo")
            .setLabel("Qual será o Cargo de Cliente?")

            modal.addComponents(
                new Discord.ActionRowBuilder()
                .addComponents(text)
            );
            await interaction.showModal(modal)
        }

    }


    if(interaction.isModalSubmit() && interaction.customId === "renovar_modal") {
        const text = interaction.fields.getTextInputValue("text")
        const channel = interaction.guild.channels.cache.get(text)
        if(!channel) {
            return interaction.reply({content:"❌ | Coloque o id de um Canal Valida!"})
        } 
        await logs.set(`renov`, text)
        const renov = interaction.guild.channels.cache.get(logs.get(`renov`))
        const vendas = interaction.guild.channels.cache.get(logs.get(`vendas`))
        const categoria = interaction.guild.channels.cache.get(logs.get(`categoria`))
        const backup = interaction.guild.channels.cache.get(logs.get(`logs_backup`))
        const cliente = interaction.guild.roles.cache.get(logs.get(`cargo_client`))
        interaction.update({
            embeds:[
                new Discord.EmbedBuilder()
                .setDescription(`Atual canal de Renovações: ${renov ?? "`Não Definido`"} \nAtual canal de Vendas: ${vendas ?? "`Não Definido`"}\n Atual Categoria de Carrinhos: ${categoria ?? "`Não Definido`"} \n Atual Logs de Backups: ${backup ?? "`Não Definido`"} \n\n Cargo de Cliente: ${cliente ?? "`Não Definido`"}`)
            ],
            components:[
                new Discord.ActionRowBuilder()
                .addComponents(
                 new Discord.StringSelectMenuBuilder()
                 .addOptions(
                    {
                        label:"Canal de Renovação",
                        value:"renovec"
                    },
                    {
                        label:"Canal de Vendas",
                        value:"vendascrec"
                    },
                    {
                        label:"Categoria de Carrinho",
                        value:"caterec"
                    },
                    {
                        label:"Logs de Backup's",
                        value:"backuprec"
                    },
                    {
                        label:"Cargo de Cliente",
                        value:"rolescl"
                    }
                 )
                 .setCustomId("logs_select")
                 .setPlaceholder("Selecione Abaixo")
                 .setMaxValues(1)
                ),
                new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId("voltar1")
                    .setLabel("Voltar")
                    .setStyle(2)
                    .setEmoji("<:voltarkauan:1177188031179010119>")
                )
            ]
        })
    }



    if(interaction.isModalSubmit() && interaction.customId === "vendas_modal") {
        const text = interaction.fields.getTextInputValue("text")
        const channel = interaction.guild.channels.cache.get(text)
        if(!channel) {
            return interaction.reply({content:"❌ | Coloque o id de um Canal Valida!"})
        } 
        await logs.set(`vendas`, text)
        const renov = interaction.guild.channels.cache.get(logs.get(`renov`))
        const vendas = interaction.guild.channels.cache.get(logs.get(`vendas`))
        const categoria = interaction.guild.channels.cache.get(logs.get(`categoria`))
        const backup = interaction.guild.channels.cache.get(logs.get(`logs_backup`))
        const cliente = interaction.guild.roles.cache.get(logs.get(`cargo_client`))
        interaction.update({
            embeds:[
                new Discord.EmbedBuilder()
                .setDescription(`Atual canal de Renovações: ${renov ?? "`Não Definido`"} \nAtual canal de Vendas: ${vendas ?? "`Não Definido`"}\n Atual Categoria de Carrinhos: ${categoria ?? "`Não Definido`"} \n Atual Logs de Backups: ${backup ?? "`Não Definido`"} \n\n Cargo de Cliente: ${cliente ?? "`Não Definido`"}`)
            ],
            components:[
                new Discord.ActionRowBuilder()
                .addComponents(
                 new Discord.StringSelectMenuBuilder()
                 .addOptions(
                    {
                        label:"Canal de Renovação",
                        value:"renovec"
                    },
                    {
                        label:"Canal de Vendas",
                        value:"vendascrec"
                    },
                    {
                        label:"Categoria de Carrinho",
                        value:"caterec"
                    },
                    {
                        label:"Logs de Backup's",
                        value:"backuprec"
                    },
                    {
                        label:"Cargo de Cliente",
                        value:"rolescl"
                    }
                 )
                 .setCustomId("logs_select")
                 .setPlaceholder("Selecione Abaixo")
                 .setMaxValues(1)
                ),
                new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId("voltar1")
                    .setLabel("Voltar")
                    .setStyle(2)
                    .setEmoji("<:voltarkauan:1177188031179010119>")
                )
            ]
        })
    }


    if(interaction.isModalSubmit() && interaction.customId === "cat_modal") {
        const text = interaction.fields.getTextInputValue("text")
        const channel = interaction.guild.channels.cache.get(text)
        if(!channel) {
            return interaction.reply({content:"❌ | Coloque o id de uma categoria Valida!"})
        } 
        await logs.set(`categoria`, text)
        const renov = interaction.guild.channels.cache.get(logs.get(`renov`))
        const vendas = interaction.guild.channels.cache.get(logs.get(`vendas`))
        const categoria = interaction.guild.channels.cache.get(logs.get(`categoria`))
        const backup = interaction.guild.channels.cache.get(logs.get(`logs_backup`))
        const cliente = interaction.guild.roles.cache.get(logs.get(`cargo_client`))
        interaction.update({
            embeds:[
                new Discord.EmbedBuilder()
                .setDescription(`Atual canal de Renovações: ${renov ?? "`Não Definido`"} \nAtual canal de Vendas: ${vendas ?? "`Não Definido`"}\n Atual Categoria de Carrinhos: ${categoria ?? "`Não Definido`"} \n Atual Logs de Backups: ${backup ?? "`Não Definido`"} \n\n Cargo de Cliente: ${cliente ?? "`Não Definido`"}`)
            ],
            components:[
                new Discord.ActionRowBuilder()
                .addComponents(
                 new Discord.StringSelectMenuBuilder()
                 .addOptions(
                    {
                        label:"Canal de Renovação",
                        value:"renovec"
                    },
                    {
                        label:"Canal de Vendas",
                        value:"vendascrec"
                    },
                    {
                        label:"Categoria de Carrinho",
                        value:"caterec"
                    },
                    {
                        label:"Logs de Backup's",
                        value:"backuprec"
                    },
                    {
                        label:"Cargo de Cliente",
                        value:"rolescl"
                    }
                 )
                 .setCustomId("logs_select")
                 .setPlaceholder("Selecione Abaixo")
                 .setMaxValues(1)
                ),
                new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId("voltar1")
                    .setLabel("Voltar")
                    .setStyle(2)
                    .setEmoji("<:voltarkauan:1177188031179010119>")
                )
            ]
        })
    }



    if(interaction.isModalSubmit() && interaction.customId === "backup_modal") {
        const text = interaction.fields.getTextInputValue("text")
        const channel = interaction.guild.channels.cache.get(text)
        if(!channel) {
            return interaction.reply({content:"❌ | Coloque o id de um Canal Valido!"})
        } 
        await logs.set(`logs_backup`, text)
        const renov = interaction.guild.channels.cache.get(logs.get(`renov`))
        const vendas = interaction.guild.channels.cache.get(logs.get(`vendas`))
        const categoria = interaction.guild.channels.cache.get(logs.get(`categoria`))
        const backup = interaction.guild.channels.cache.get(logs.get(`logs_backup`))
        const cliente = interaction.guild.roles.cache.get(logs.get(`cargo_client`))
        interaction.update({
            embeds:[
                new Discord.EmbedBuilder()
                .setDescription(`Atual canal de Renovações: ${renov ?? "`Não Definido`"} \nAtual canal de Vendas: ${vendas ?? "`Não Definido`"}\n Atual Categoria de Carrinhos: ${categoria ?? "`Não Definido`"} \n Atual Logs de Backups: ${backup ?? "`Não Definido`"} \n\n Cargo de Cliente: ${cliente ?? "`Não Definido`"}`)
            ],
            components:[
                new Discord.ActionRowBuilder()
                .addComponents(
                 new Discord.StringSelectMenuBuilder()
                 .addOptions(
                    {
                        label:"Canal de Renovação",
                        value:"renovec"
                    },
                    {
                        label:"Canal de Vendas",
                        value:"vendascrec"
                    },
                    {
                        label:"Categoria de Carrinho",
                        value:"caterec"
                    },
                    {
                        label:"Logs de Backup's",
                        value:"backuprec"
                    },
                    {
                        label:"Cargo de Cliente",
                        value:"rolescl"
                    }
                 )
                 .setCustomId("logs_select")
                 .setPlaceholder("Selecione Abaixo")
                 .setMaxValues(1)
                ),
                new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId("voltar1")
                    .setLabel("Voltar")
                    .setStyle(2)
                    .setEmoji("<:voltarkauan:1177188031179010119>")
                )
            ]
        })
    }

    if(interaction.isModalSubmit() && interaction.customId === "role_modal") {
        const text = interaction.fields.getTextInputValue("text")
        const role = interaction.guild.roles.cache.get(text)
        if(!role) {
            return interaction.reply({content:"❌ | Coloque o id de um cargo Valido!"})
        } 
        await logs.set(`cargo_client`, text)
        const renov = interaction.guild.channels.cache.get(logs.get(`renov`))
        const vendas = interaction.guild.channels.cache.get(logs.get(`vendas`))
        const categoria = interaction.guild.channels.cache.get(logs.get(`categoria`))
        const backup = interaction.guild.channels.cache.get(logs.get(`logs_backup`))
        const cliente = interaction.guild.roles.cache.get(logs.get(`cargo_client`))
        interaction.update({
            embeds:[
                new Discord.EmbedBuilder()
                .setDescription(`Atual canal de Renovações: ${renov ?? "`Não Definido`"} \nAtual canal de Vendas: ${vendas ?? "`Não Definido`"}\n Atual Categoria de Carrinhos: ${categoria ?? "`Não Definido`"} \n Atual Logs de Backups: ${backup ?? "`Não Definido`"} \n\n Cargo de Cliente: ${cliente ?? "`Não Definido`"}`)
            ],
            components:[
                new Discord.ActionRowBuilder()
                .addComponents(
                 new Discord.StringSelectMenuBuilder()
                 .addOptions(
                    {
                        label:"Canal de Renovação",
                        value:"renovec"
                    },
                    {
                        label:"Canal de Vendas",
                        value:"vendascrec"
                    },
                    {
                        label:"Categoria de Carrinho",
                        value:"caterec"
                    },
                    {
                        label:"Logs de Backup's",
                        value:"backuprec"
                    },
                    {
                        label:"Cargo de Cliente",
                        value:"rolescl"
                    }
                 )
                 .setCustomId("logs_select")
                 .setPlaceholder("Selecione Abaixo")
                 .setMaxValues(1)
                ),
                new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId("voltar1")
                    .setLabel("Voltar")
                    .setStyle(2)
                    .setEmoji("<:voltarkauan:1177188031179010119>")
                )
            ]
        })
    }
    
    if(interaction.isStringSelectMenu() && interaction.customId === "api_select_menu") {
        const options = interaction.values[0]
        const a = msg[interaction.message.id];
        if(a !== interaction.user.id) {interaction.deferUpdate() 
            return;}
        if(options === "squareapi"){
            const modal = new Discord.ModalBuilder()
            .setTitle("Api Key")
            .setCustomId("apikeysquare_modal");

            const text = new Discord.TextInputBuilder()
            .setLabel("Qual a sua apikey?")
            .setStyle(1)
            .setCustomId("text")
            .setRequired(true)
            modal.addComponents(new Discord.ActionRowBuilder().addComponents(text))
            await interaction.showModal(modal)
        }
        if(options === "mpapi") {
            const modal = new Discord.ModalBuilder()
            .setTitle("Api Key")
            .setCustomId("apikeymp_modal");

            const text = new Discord.TextInputBuilder()
            .setLabel("Qual a sua apikey?")
            .setStyle(1)
            .setCustomId("text")
            .setRequired(true)
            modal.addComponents(new Discord.ActionRowBuilder().addComponents(text))
            await interaction.showModal(modal)
        }
    }
    if(interaction.isModalSubmit() && interaction.customId === "apikeymp_modal") {
        
        const text = interaction.fields.getTextInputValue("text")
        await api.set(`mp`, `${text}`)
        const square = api.get(`square`)
        const mp = api.get(`mp`)
        
        interaction.update({
            embeds:[
                new Discord.EmbedBuilder()
                .setDescription(`Atual ApiKey SquareCloud: ${square === null ? "`Não Definido`" : `||${square}||`} \n Atual Mercado Pago ApiKey: ${mp === null ? "`Não Definido`" : `||${mp}||`}`)
            ],
            components:[
                new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.StringSelectMenuBuilder()
                    .addOptions(
                        {
                            label:"Alterar Square API Key",
                            emoji:"📦",
                            value:"squareapi"
                        },
                        {
                            label:"Alterar Mercado Pago Api",
                            emoji:"📦",
                            value:"mpapi"
                        }
                    )
                    .setCustomId("api_select_menu")
                    .setPlaceholder("Selecione abaixo")
                ),
                new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId("voltar1")
                    .setLabel("Voltar")
                    .setStyle(2)
                    .setEmoji("<:voltarkauan:1177188031179010119>")
                )
            ]
        })
    }
    if(interaction.isModalSubmit() && interaction.customId === "apikeysquare_modal") {
        const text = interaction.fields.getTextInputValue("text")
        await api.set(`square`, `${text}`)
        const square = api.get(`square`)
        const mp = api.get(`mp`)
        
        interaction.update({
            embeds:[
                new Discord.EmbedBuilder()
                .setDescription(`Atual ApiKey SquareCloud: ${square === null ? "`Não Definido`" : `||${square}||`} \n Atual Mercado Pago ApiKey: ${mp === null ? "`Não Definido`" : `||${mp}||`}`)
            ],
            components:[
                new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.StringSelectMenuBuilder()
                    .addOptions(
                        {
                            label:"Alterar Square API Key",
                            emoji:"📦",
                            value:"squareapi"
                        },
                        {
                            label:"Alterar Mercado Pago Api",
                            emoji:"📦",
                            value:"mpapi"
                        }
                    )
                    .setCustomId("api_select_menu")
                    .setPlaceholder("Selecione abaixo")
                ),
                new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId("voltar1")
                    .setLabel("Voltar")
                    .setStyle(2)
                    .setEmoji("<:voltarkauan:1177188031179010119>")
                )
            ]
        })
    }

    if(interaction.isModalSubmit() && interaction.customId === "alt_vatar_modal") {
        const text = interaction.fields.getTextInputValue("text")
        client.user.setAvatar(`${text}`).then(() => {
            interaction.reply({
                embeds:[
                    new Discord.EmbedBuilder()
                    .setDescription(`✅ | Alterado com sucesso!`)
                ],
                ephemeral:true
            })
        }).catch(() => {
            interaction.reply({
                embeds:[
                    new Discord.EmbedBuilder()
                    .setDescription(`❌ | Ocorreu um erro ao tentar alterar o avatar!`)
                ],
                ephemeral:true
            })
        })
    }

    if(interaction.isModalSubmit() && interaction.customId === "alt_nome_modal") {
        const text = interaction.fields.getTextInputValue("text")
        client.user.setUsername(`${text}`).then(() => {
            interaction.reply({
                embeds:[
                    new Discord.EmbedBuilder()
                    .setDescription(`✅ | Alterado com sucesso!`)
                ],
                ephemeral:true
            })
        }).catch(() => {
            interaction.reply({
                embeds:[
                    new Discord.EmbedBuilder()
                    .setDescription(`❌ | Ocorreu um erro ao tentar alterar o nome!`)
                ],
                ephemeral:true
            })
        })
    }
    
    if(interaction.isButton() && interaction.customId === "voltar1") {
        const a = msg[interaction.message.id];
        if(a !== interaction.user.id) {interaction.deferUpdate() 
            return;}
        interaction.update({
            embeds:[
                new Discord.EmbedBuilder()
                .setTitle(`⚙ ${interaction.guild.name} | Configuração ⚙`)
                .setDescription(`Selectione abaixo qual opção deseja alterar no seu bot. É importante que você preste atenção nas configurações atuais para garantir que suas alterações sejam feitas corretamente. 💥`)
            ],
            components:[
                new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.StringSelectMenuBuilder()
                    .addOptions(
                        {
                            label:"Alterar Nome",
                            description:"Altere o nome do BOT",
                            value:"alt_nome",
                            emoji:"🪪"
                        },
                        {
                            label:"Alterar Avatar",
                            description:"Altere o avatar do BOT",
                            value:"alt_avatar",
                            emoji:"🖼"
                        },
                        {
                            label:"Configurar LOGS",
                            description:"Configurações sobre as LOGS",
                            value:"config_logs_select",
                            emoji:"<:Termos001:1178362734199455804>"
                        },
                        {
                            label:"Configurar Chaves API",
                            description:"Configurações sobre suas CHAVES APIS",
                            value:"config_api_select",
                            emoji:"🤖"
                        },
                    )
                    .setCustomId("basic_select")
                    .setPlaceholder("Selecione abaixo qual Configurações Basicas deseja fazer")
                ),
                new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId("voltar")
                    .setLabel("Voltar")
                    .setStyle(2)
                    .setEmoji("<:voltarkauan:1177188031179010119>")
                )
            ]
        })
    }
})

/*===========================================|___CARRINHO___|=====================================================*/
client.on("interactionCreate", async (interaction) => {
    if(interaction.isButton()) {
        const id = interaction.customId
        const epd = db.get(`${id}`)
        if(epd) {
            if (interaction.guild.channels.cache.find(c => c.topic === interaction.user.id)) {
                const channel = interaction.guild.channels.cache.find(c => c.topic === interaction.user.id);
                return interaction.reply({
                  content: `Você já tem um carrinho criado!`,
                  ephemeral: true,
                  components: [
                    new Discord.ActionRowBuilder().addComponents(
                      new Discord.ButtonBuilder()
                        .setStyle(5)
                        .setLabel('🛒・Ir para carrinho')
                        .setURL(`https://discord.com/channels/${channel.guild.id}/${channel.id}`)
                    )
                  ]
                });
              }        
              const api1 = new SquareCloudAPI(await api.get(`square`));
            
            const msg = await interaction.reply({content:"Aguarde um momento, estou criando seu carrinho..", ephemeral:true})
            interaction.guild.channels.create({
                name:`🛒-carrinho-${interaction.user.username}`,
                parent: logs.get(`categoria`),
                type: Discord.ChannelType.GuildText,
                topic: interaction.user.id,
                permissionOverwrites: [
                    {
                        id:interaction.user.id,
                        allow:["ViewChannel"],
                        deny:["SendMessages"]
                    }
                ],
            }).then(async (channel) => {
                msg.edit({
                    content:"",
                    embeds:[
                        new Discord.EmbedBuilder()
                        .setDescription(`✅**|${interaction.user}, seu CARRINHO foi aberito [CLIQUE AQUI](${channel.url}) para encontra-lo.**`)
                    ],
                    components:[
                        new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.ButtonBuilder()
                            .setLabel("Ir para o Carrinho")
                            .setStyle(5)
                            .setEmoji("🛒")
                            .setURL(channel.url)
                        )
                    ]
                })
                const row = new Discord.ActionRowBuilder()
                if(epd.preco.mensal.onoff === true){
                    row.addComponents(
                        new Discord.ButtonBuilder()
                        .setEmoji("📅")
                        .setLabel("30 Dias")
                        .setStyle(1)
                        .setCustomId("30diascarrinho")
                    )
                }
                if(epd.preco.quizena.onoff === true){
                    row.addComponents(
                        new Discord.ButtonBuilder()
                        .setEmoji("📅")
                        .setLabel("15 Dias")
                        .setStyle(1)
                        .setCustomId("15diascarrinho")
                    )
                }
                if(epd.preco.semanal.onoff === true){
                    row.addComponents(
                        new Discord.ButtonBuilder()
                        .setEmoji("📅")
                        .setLabel("7 Dias")
                        .setStyle(1)
                        .setCustomId("7diascarrinho")
                    )
                }
                row.addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId("cancelarcart")
                    .setEmoji("<:nao:1116869877848883210>")
                    .setLabel("Cancelar")
                    .setStyle(4)
                )
                var data_id = Math.floor(Math.random() * 999999999999999);
                await channel.send({
                    content:`# CARRINHO - ${data_id}`
                })

                const user = interaction.user
                await channel.send({
                    content:`${interaction.user}`,
                    embeds:[
                        new Discord.EmbedBuilder()
                        .setTitle(`${interaction.guild.name} | Sistema de Compras`)
                        .setDescription(`👋| Olá ${interaction.user} \n\n- **Selecione uma das opções:**\n\n${db.get(`${id}.preco.mensal.onoff`) === true ? `> Mensal (30 dias) R$${db.get(`${id}.preco.mensal.preco`)}` : " "} \n ${db.get(`${id}.preco.quizena.onoff`) === true ? `> Quinzena (15 dias) R$${db.get(`${id}.preco.quizena.preco`)}` : " "} \n ${db.get(`${id}.preco.semanal.onoff`) === true ? `> Semanal (7 dias) R$${db.get(`${id}.preco.semanal.preco`)}` : " "}`)
                    ],
                    components:[
                        row
                    ]
                }).then((msg) => {
                    

                let quantidade = 1
                let Dias = 0
                let preco = 0
                let tipo = ""
                let useraprov = ""
                

                client.on("interactionCreate" , async(interaction) => {
                        

                    if(interaction.isButton() && interaction.customId === "enviar_bot") {
                        const modal = new Discord.ModalBuilder()
                        .setTitle(`${interaction.guild.name} - Upar BOT`)
                        .setCustomId("uparbot_modal");

                        const nome = new Discord.TextInputBuilder()
                        .setCustomId("nomeapp")
                        .setLabel("Nome da Aplicação")
                        .setStyle(1)
                        .setRequired(true);
                        

                        const iddono = new Discord.TextInputBuilder()
                        .setCustomId("idapp")
                        .setLabel("ID QUE SERÁ SETADO COMO DONO DO BOT?")
                        .setStyle(1)
                        .setRequired(true);
                        

                        const tokenbot = new Discord.TextInputBuilder()
                        .setCustomId("tokenapp")
                        .setLabel("TOKEN DO BOT")
                        .setStyle(1)
                        .setRequired(true);
                        
                        modal.addComponents(new Discord.ActionRowBuilder().addComponents(nome))
                        modal.addComponents(new Discord.ActionRowBuilder().addComponents(iddono))
                        modal.addComponents(new Discord.ActionRowBuilder().addComponents(tokenbot))
                        await interaction.showModal(modal)
                    }

                    if(interaction.isModalSubmit() && interaction.customId === "uparbot_modal") {
                        const nome = interaction.fields.getTextInputValue("nomeapp");
                        const iddono = interaction.fields.getTextInputValue("idapp")
                        const tokenbot = interaction.fields.getTextInputValue("tokenapp")

                       const msg123 = await interaction.reply({
                            content:"🔁 | Enviando Bot...",
                            ephemeral:true
                        })
                        fs.readFile(`source/${id}.zip`, function(err, data) {
                            if (err) throw err;
                            JSZip.loadAsync(data).then(function (zip) {
                                
                                zip.file('config.json').async('string').then(function(content) {
                                    
                                    let config = JSON.parse(content);
                                    config.token = `${tokenbot}`;  
                        
                                    
                                    zip.file('config.json', JSON.stringify(config));
                        
                                    
                                    zip.generateAsync({type:'nodebuffer'}).then(function(content) {
                                        fs.writeFile(`source/client/${nome}.zip`, content, function(err) {
                                            if (err) throw err;
                                            
                                            const dir = 'source/client';
                                            const nome1 = `${nome}.zip`;
                                            const filePath = path.join(dir, nome1);

                                            try {
                                                const data = api1.applications.create(filePath).then((data) => {
                                                    fs.unlink(filePath, function(err) {
                                                        if (err) throw err;
                                                        console.log('Arquivo zip excluído com sucesso!');
                                                    });
                                                    msg123.edit({
                                                        content:`✅ | Bot enviado, use /apps para gerenciá-lo\n⚠ | id da sua aplicação: ${data.id} \n💥| esse Canal será apagado em 15 segundos!`,

                                                    })
                                                    setTimeout(() => {
                                                       channel.delete() 
                                                    }, 15000);
                                                }).catch((err) => {
                                                    fs.unlink(`source/client/${nome1}`, function(err) {
                                                        if (err) throw err;
                                                        console.log('Arquivo zip excluído com sucesso!');
                                                    });
                                                    msg123.edit(`Ocorreu um erro para enviar, olhe suas logs`)
                                                    console.log(err)
                                                })
                                              } catch (err){
                                                fs.unlink(`source/client/${nome1}`, function(err) {
                                                    if (err) throw err;
                                                    console.log('Arquivo zip excluído com sucesso!');
                                                });
                                                msg123.edit({content:"Ocorreu um erro para fazer o upload verifique as logs"})
                                                console.log(err)
                                                
                                              }
                                  
                                            
                        
                                            
                                            
                                        });
                                    });
                                });
                            });
                        });
                        
                    }


                    })
                client.on("interactionCreate" , async(interaction) => {
                    if(interaction.customId === "aprovar") {
                        if(interaction.user.id !== perms.get(`${interaction.user.id}_id`)) {
                            return interaction.reply({content:"Você não tem permissão para usar este comando.", ephemeral:true})
                        }
                        useraprov = interaction.user.id
                        await db1.set(`carrinho_${channel.id}.status`, "Processando")
                        interaction.reply({
                            embeds:[
                                new Discord.EmbedBuilder()
                                .setDescription(`✅ | Compra Aprovada com sucesso!`)
                            ],
                            ephemeral:true
                        })
                     }
                 })
                const interação = msg.createMessageComponentCollector({ componentType: Discord.ComponentType.Button });
                interação.on("collect", async (interaction) => {
                    if (user.id !== interaction.user.id) {
                        interaction.deferUpdate()
                       return;
                     } 
                    let intervalId;
                    intervalId = setInterval(() => {
                        if(db1.get(`carrinho_${channel.id}.status`) === "Processando") {
                            const usuariosa = interaction.member 
                            usuariosa.roles.add(logs.get(`cargo_client`)).catch((err) => {console.log(`Usuario Já tem Cargo..`); })
                            db1.set(`carrinho_${channel.id}.status`, "Aprovado")
                            clearInterval(intervalId);
                            channel.bulkDelete(50).then(async() => {
                                await channel.send({
                                    content:`✅ | Pagamento Aprovado \n🆔 | ID da Compra: ${data_id} \n🪐 | Produto: ${id} x${quantidade} - (${Dias * quantidade} Dias)\n💵 | Valor: R$${Number(preco) * Number(quantidade)}`
                                }).then(() => {
                                    
                                channel.send({
                                    content:`${interaction.user}`,

                                    embeds:[
                                        new Discord.EmbedBuilder()
                                        .setTitle(`🎉 ${interaction.guild.name} | Pagamento Aprovado 🎉`)
                                        .setDescription(`**💥 | O Pagamento foi aprovado, irei precisar de algumas informações para enviar o seu bot, são elas:** \n\n> - Nome que você irá querer na aplicação; \n> - Id que será setado como dono do bot; \n> - Token do Bot, \n\n **OBS: ⚠ | Mantenha o token do bot seguro. Não compartilhe com ninguém!** \n\n**Siga o tutorial disponivel nos botões abaixo, qualquer dúvida estamos a disposição!**`)
                                    ],
                                    components:[
                                        new Discord.ActionRowBuilder()
                                        .addComponents(
                                            new Discord.ButtonBuilder()
                                            .setLabel("Enviar Bot")
                                            .setStyle(3)
                                            .setCustomId("enviar_bot"),
                                            new Discord.ButtonBuilder()
                                            .setLabel("Portal Desenvolvedor")
                                            .setEmoji("<:review:1178761503877378069>")
                                            .setStyle(5)
                                            .setURL("https://discord.com/developers/applications/"),
                                            new Discord.ButtonBuilder()
                                            .setLabel("Video Tutorial")
                                            .setStyle(5)
                                            .setEmoji("<:bot:989614012020953218>")
                                            .setURL("https://www.youtube.com/watch?v=7PiVqEMHi_0&t=392s"),
                                        )
                                    ]
                                })
                                })
                            })
                            interaction.guild.channels.cache.get(logs.get(`vendas`)).send({
                                embeds:[
                                    new Discord.EmbedBuilder()
                                    .setTitle(`${interaction.guild.name} | Sistema de Logs`)
                                    .addFields(
                                        { name: '👥 | Usuário:', value: `<@${useraprov}> - \`${useraprov}\`` },
                                        { name: '📝 | Aprovou o Carrinho:', value: `Produto: ${epd.nomeproduto} - \`${data_id}\`` },
                                        { name: '🕒 | Data / Horário do Aprovamento:',  value: `<t:${Math.floor(new Date() / 1000)}:f> (<t:${~~(new Date() / 1000)}:R>)` }
                                    )
                                ]
                            })

                        }
                    }, 15000);
                    let temp;
                    function func() {
                        const asdaslog = new Discord.EmbedBuilder()
                        .setTitle(`${interaction.guild.name} | Compra Cancelada`)
   .addFields(
    { name: '👥 | Usuário:', value: `${interaction.user.username} - \`${interaction.user.id}\`` },
    { name: '📝 | Motivo:', value: `\`Cancelada pelo usuário.\`` },
    { name: '🕒 | Data / Horário:', value: `<t:${Math.floor(new Date() / 1000)}:f> (<t:${~~(new Date() / 1000)}:R>)` }
  )
  .setTimestamp()
  .setThumbnail(interaction.user.displayAvatarURL({ format: "png" }))
  const button26 = new Discord.ButtonBuilder()
                     .setCustomId('comprarcancelar')
                     .setLabel('Mensagem Automática')
                     .setStyle(2)
                     .setDisabled(true)
                     const row27 = new Discord.ActionRowBuilder().addComponents(button26);
                        client.channels.cache.get(logs.get(`vendas`)).send({ embeds: [asdaslog], components: [row27]})

                        const embedcancelar3 = new Discord.EmbedBuilder()
      .setTitle(`${interaction.guild.name} | Compra Cancelada`)
      .setDescription(`Olá ${interaction.user},\n\n• A sua compra foi cancelada por **inatividade**, e todos os produtos foram devolvidos para o estoque. Você pode voltar a comprar quando quiser!`)
      const button2 = new Discord.ButtonBuilder()
                     .setCustomId('comprarcancelar')
                     .setLabel('Mensagem Automática')
                     .setStyle(2)
                     .setDisabled(true)
                     const row22 = new Discord.ActionRowBuilder().addComponents(button2);
      interaction.user.send({ embeds: [embedcancelar3], components: [row22] })
                       if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }
                        db1.delete(`carrinho_${channel.id}`)
                        clearTimeout(temp)
                      
                    }
                    temp = setTimeout(func, 600000 )

                    function reinciar() {
                        clearTimeout(temp); 
                        temp = setTimeout(func, 600000); 
                    }



                        
                    if(interaction.customId === "7diascarrinho") {
                        reinciar()
                        tipo = "semanal"
                        
                        preco = epd.preco.semanal.preco
                        Dias = 7
                        db1.set(`carrinho_${interaction.channel.id}`, {
                            quantia: quantidade,
                            userid: interaction.user.id,
                            id:data_id,
                            produto:id,
                            status:"Aguardando..."
                        })
                        interaction.update({
                            embeds:[
                                new Discord.EmbedBuilder()
                                .setTitle(`${interaction.guild.name} | Sistema de Compras`)
                                .setDescription(`📦 | Produto: **${id}** ${tipo} x${quantidade} - (${Dias * quantidade} Dias)\n\n💰 | Valor: R$${Number(preco) * Number(quantidade)}`)
                            ],
                            components:[
                                new Discord.ActionRowBuilder()
                                .addComponents(
                                    new Discord.ButtonBuilder()
                                    .setCustomId("adicionarcarrinho")
                                    .setLabel("+")
                                    .setStyle(2),
                                    new Discord.ButtonBuilder()
                                    .setCustomId("comprar")
                                    .setLabel("Comprar")
                                    .setStyle(3)
                                    .setEmoji("<a:1150938888479703081:1155318227736469555>"),
                                    new Discord.ButtonBuilder()
                                    .setCustomId("removercarrinho")
                                    .setLabel("-")
                                    .setStyle(2),
                                    new Discord.ButtonBuilder()
                                    .setCustomId("cancelar")
                                    .setLabel("Cancelar")
                                    .setStyle(4)
                                    .setEmoji("<a:1150939352503963768:1155318230345322507>")
                                )
                            ]
                        })
                        interaction.guild.channels.cache.get(logs.get(`vendas`)).send({
                            embeds:[
                                new Discord.EmbedBuilder()
                                .setTitle(`${interaction.guild.name} | Sistema de Logs`)
                                .addFields(
                                    { name: '👥 | Usuário:', value: `${interaction.user.username} - \`${interaction.user.id}\`` },
                                    { name: '📝 | Criou um Carrinho:', value: `Produto: ${epd.nomeproduto} - \`${data_id}\`` },
                                    { name: '🕒 | Data / Horário da Compra:',  value: `<t:${Math.floor(new Date() / 1000)}:f> (<t:${~~(new Date() / 1000)}:R>)` }
                                )
                            ]
                        })
                     }

                        
                     if(interaction.customId === "15diascarrinho") {
                        reinciar()
                        tipo = "Quinzena"
                        
                        preco = epd.preco.quizena.preco
                        Dias = 15
                        db1.set(`carrinho_${interaction.channel.id}`, {
                            quantia: quantidade,
                            userid: interaction.user.id,
                            id:data_id,
                            produto:id,
                            status:"Aguardando..."
                        })
                        interaction.update({
                            embeds:[
                                new Discord.EmbedBuilder()
                                .setTitle(`${interaction.guild.name} | Sistema de Compras`)
                                .setDescription(`📦 | Produto: **${id}** ${tipo} x${quantidade} - (${Dias * quantidade} Dias)\n\n💰 | Valor: R$${Number(preco) * Number(quantidade)}`)
                            ],
                            components:[
                                new Discord.ActionRowBuilder()
                                .addComponents(
                                    new Discord.ButtonBuilder()
                                    .setCustomId("adicionarcarrinho")
                                    .setLabel("+")
                                    .setStyle(2),
                                    new Discord.ButtonBuilder()
                                    .setCustomId("comprar")
                                    .setLabel("Comprar")
                                    .setStyle(3)
                                    .setEmoji("<a:1150938888479703081:1155318227736469555>"),
                                    new Discord.ButtonBuilder()
                                    .setCustomId("removercarrinho")
                                    .setLabel("-")
                                    .setStyle(2),
                                    new Discord.ButtonBuilder()
                                    .setCustomId("cancelar")
                                    .setLabel("Cancelar")
                                    .setStyle(4)
                                    .setEmoji("<a:1150939352503963768:1155318230345322507>")
                                )
                            ]
                        })
                        interaction.guild.channels.cache.get(logs.get(`vendas`)).send({
                            embeds:[
                                new Discord.EmbedBuilder()
                                .setTitle(`${interaction.guild.name} | Sistema de Logs`)
                                .addFields(
                                    { name: '👥 | Usuário:', value: `${interaction.user.username} - \`${interaction.user.id}\`` },
                                    { name: '📝 | Criou um Carrinho:', value: `Produto: ${epd.nomeproduto} - \`${data_id}\`` },
                                    { name: '🕒 | Data / Horário da Compra:',  value: `<t:${Math.floor(new Date() / 1000)}:f> (<t:${~~(new Date() / 1000)}:R>)` }
                                )
                            ]
                        })
                     }

                        
                     if(interaction.customId === "30diascarrinho") {
                        reinciar()
                        tipo = "Mensal"
                        
                        preco = epd.preco.mensal.preco
                        Dias = 30
                        
                        db1.set(`carrinho_${interaction.channel.id}`, {
                            quantia: quantidade,
                            userid: interaction.user.id,
                            id:data_id,
                            produto:id,
                            status:"Aguardando..."
                        })
                        interaction.update({
                            embeds:[
                                new Discord.EmbedBuilder()
                                .setTitle(`${interaction.guild.name} | Sistema de Compras`)
                                .setDescription(`📦 | Produto: **${id}** ${tipo} x${quantidade} - (${Dias * quantidade} Dias)\n\n💰 | Valor: R$${Number(preco) * Number(quantidade)}`)
                            ],
                            components:[
                                new Discord.ActionRowBuilder()
                                .addComponents(
                                    new Discord.ButtonBuilder()
                                    .setCustomId("adicionarcarrinho")
                                    .setLabel("+")
                                    .setStyle(2),
                                    new Discord.ButtonBuilder()
                                    .setCustomId("comprar")
                                    .setLabel("Comprar")
                                    .setStyle(3)
                                    .setEmoji("<a:1150938888479703081:1155318227736469555>"),
                                    new Discord.ButtonBuilder()
                                    .setCustomId("removercarrinho")
                                    .setLabel("-")
                                    .setStyle(2),
                                    new Discord.ButtonBuilder()
                                    .setCustomId("cancelar")
                                    .setLabel("Cancelar")
                                    .setStyle(4)
                                    .setEmoji("<a:1150939352503963768:1155318230345322507>")
                                )
                            ]
                        })
                        interaction.guild.channels.cache.get(logs.get(`vendas`)).send({
                            embeds:[
                                new Discord.EmbedBuilder()
                                .setTitle(`${interaction.guild.name} | Sistema de Logs`)
                                .addFields(
                                    { name: '👥 | Usuário:', value: `${interaction.user.username} - \`${interaction.user.id}\`` },
                                    { name: '📝 | Criou um Carrinho:', value: `Produto: ${epd.nomeproduto} - \`${data_id}\`` },
                                    { name: '🕒 | Data / Horário da Compra:',  value: `<t:${Math.floor(new Date() / 1000)}:f> (<t:${~~(new Date() / 1000)}:R>)` }
                                )
                            ]
                        })
                     }
            
                 if(interaction.customId === "comprar") {
                    reinciar()
                    const moment = require("moment");
                    moment.locale("pt-br");
                    const min = moment().add(10, 'minutes');
                    const time = Math.floor(min.valueOf() / 1000);
                    
                    interaction.update({
                        embeds:[
                            new Discord.EmbedBuilder()
                            .setTitle(`${interaction.guild.name} | Sistema de Compra`)
                            .setDescription(`\`\`\`Pague com pix para comprar seu BOT \`\`\``)
                            .addFields(
                                {
                                    name:"🌎 | Produto:",
                                    value:`${id}`
                                },
                                {
                                    name:"💸 | Valor",
                                    value:`R$${Number(preco) * Number(quantidade)}`
                                },
                                {
                                    name:"Pagamento expira em:",
                                    value:`<t:${time}:f> (<t:${time}:R>)`
                                }
                            )
                        ],
                        components:[
                            new Discord.ActionRowBuilder()
                            .addComponents(
                                new Discord.ButtonBuilder()
                                .setCustomId("pixcarrinho")
                                .setLabel("Pix")
                                .setStyle(1)
                                .setEmoji("<:PIX:1135113811548966942>"),
                                new Discord.ButtonBuilder()
                                .setCustomId("cancelar")
                                .setLabel("Cancelar")
                                .setStyle(4)
                                .setEmoji("<a:1150939352503963768:1155318230345322507>")
                            )
                        ]
                    })
                 }
                 if(interaction.customId === "pixcarrinho") {
                    interaction.update({
                        components:[
                            new Discord.ActionRowBuilder()
                            .addComponents(
                                new Discord.ButtonBuilder()
                                .setCustomId("pix")
                                .setLabel("Pix Copiar e colar")
                                .setEmoji("<:PIX:1135113811548966942>")
                                .setStyle(1),
                                new Discord.ButtonBuilder()
                                .setCustomId("qrcode")
                                .setLabel("Qr Code")
                                .setEmoji("<:PIX:1135113811548966942>")
                                .setStyle(1),
                                new Discord.ButtonBuilder()
                                .setCustomId("aprovar")
                                .setLabel("Aprovar Compra")
                                .setEmoji("<:PIX:1135113811548966942>")
                                .setStyle(3),
                                new Discord.ButtonBuilder()
                                .setCustomId("cancelar")
                                .setLabel("Cancelar")
                                .setStyle(4)
                                .setEmoji("<a:1150939352503963768:1155318230345322507>")
                            )
                        ]
                    })
                 }
                
                 if(interaction.customId === "qrcode") {
                    try{
                        interaction.reply({
                            embeds:[
                                new Discord.EmbedBuilder()
                                .setDescription(`➡Segue abaixo a **QR CODE** do seu pagamento e envie o comprovante...`)
                                .setImage(`${pix.get(`pix.qrcode`)}`)
                            ],
                            ephemeral:true
                        }).catch(() => {
                            interaction.reply({
                                embeds:[
                                    new Discord.EmbedBuilder()
                                    .setDescription(`❌ | Ocorreu um erro ao tentar abrir o **QR CODE**`)
                                ],
                                ephemeral:true
                            })
                        })
                    } catch{
                        interaction.reply({
                            embeds:[
                                new Discord.EmbedBuilder()
                                .setDescription(`❌ | Ocorreu um erro ao tentar abrir o **QR CODE**\n Possivelmente o **QR CODE** está desabilitado...`)
                            ],
                            ephemeral:true
                        })
                    }
                    interaction.channel.edit({
                        permissionOverwrites:[
                            {
                                id: interaction.guild.id,
                                deny:["ViewChannel", "SendMessages"]
                            },
                            {
                                id: interaction.user.id,
                                allow:["ViewChannel", "SendMessages"]
                            },
                        ]
                    })
                 }
                 if(interaction.customId === "pix") {
                    interaction.reply({
                        embeds:[
                            new Discord.EmbedBuilder()
                            .setDescription(`➡Segue abaixo a **CHAVE PIX** do seu pagamento e envie o comprovante...\`\`\`${pix.get(`pix.chave`)}\`\`\``)
                        ],
                        ephemeral:true
                    })
                    interaction.channel.edit({
                        permissionOverwrites:[
                            {
                                id: interaction.guild.id,
                                deny:["ViewChannel", "SendMessages"]
                            },
                            {
                                id: interaction.user.id,
                                allow:["ViewChannel", "SendMessages"]
                            },
                        ]
                    })
                 }
                 if(interaction.customId === "cancelar") {
                    
                    interaction.guild.channels.cache.get(logs.get(`vendas`)).send({
                        embeds:[
                            new Discord.EmbedBuilder()
                            .setTitle(`${interaction.guild.name} | Sistema de Logs`)
                            .addFields(
                                { name: '👥 | Usuário:', value: `${interaction.user.username} - \`${interaction.user.id}\`` },
                                { name: '📝 | Encerrou um Carrinho:', value: `Produto: ${epd.nomeproduto} - \`${data_id}\`` },
                                { name: '📝 | Motivo:', value: `\`Cancelada pelo usuário.\`` },
                                { name: '🕒 | Data / Horário do fechamento:',  value: `<t:${Math.floor(new Date() / 1000)}:f> (<t:${~~(new Date() / 1000)}:R>)` }
                            )
                        ]
                    });
                    channel.delete();
                    db1.delete(`carrinho_${interaction.channel.id}`);

                 }
                 if(interaction.customId === "adicionarcarrinho") {
                    quantidade++;
                    db1.add(`carrinho_${interaction.channel.id}.quantia`, 1);
                    interaction.update({
                        embeds:[
                            new Discord.EmbedBuilder()
                            .setTitle(`${interaction.guild.name} | Sistema de Compras`)
                            .setDescription(`📦 | Produto: **${id}** ${tipo} x${quantidade} - (${Dias * quantidade} Dias)\n\n💰 | Valor: R$${Number(preco) * Number(quantidade)}`)
                        ],
                        components:[
                            new Discord.ActionRowBuilder()
                            .addComponents(
                                new Discord.ButtonBuilder()
                                .setCustomId("adicionarcarrinho")
                                .setLabel("+")
                                .setStyle(2),
                                new Discord.ButtonBuilder()
                                .setCustomId("comprar")
                                .setLabel("Comprar")
                                .setStyle(3)
                                .setEmoji("<a:1150938888479703081:1155318227736469555>"),
                                new Discord.ButtonBuilder()
                                .setCustomId("removercarrinho")
                                .setLabel("-")
                                .setStyle(2),
                                new Discord.ButtonBuilder()
                                .setCustomId("cancelar")
                                .setLabel("Cancelar")
                                .setStyle(4)
                                .setEmoji("<a:1150939352503963768:1155318230345322507>")
                            )
                        ]
                    })
                   
                 }
                 if(interaction.customId === "removercarrinho") {
                    if(quantidade < 2) {
                        interaction.reply({
                            embeds:[
                                new Discord.EmbedBuilder()
                                .setDescription(`❌ | Você só pode colocar de 1 pra cima`)
                            ],
                            ephemeral:true
                        })
                        return;
                    }
                    quantidade--;
                    db1.set(`carrinho_${interaction.channel.id}.quantia`, quantidade)
                    interaction.update({
                        embeds:[
                            new Discord.EmbedBuilder()
                            .setTitle(`${interaction.guild.name} | Sistema de Compras`)
                            .setDescription(`📦 | Produto: **${id}** ${tipo} x${quantidade} - (${Dias * quantidade} Dias)\n\n💰 | Valor: R$${Number(preco) * Number(quantidade)}`)
                        ],
                        components:[
                            new Discord.ActionRowBuilder()
                            .addComponents(
                                new Discord.ButtonBuilder()
                                .setCustomId("adicionarcarrinho")
                                .setLabel("+")
                                .setStyle(2),
                                new Discord.ButtonBuilder()
                                .setCustomId("comprar")
                                .setLabel("Comprar")
                                .setStyle(3)
                                .setEmoji("<a:1150938888479703081:1155318227736469555>"),
                                new Discord.ButtonBuilder()
                                .setCustomId("removercarrinho")
                                .setLabel("-")
                                .setStyle(2),
                                new Discord.ButtonBuilder()
                                .setCustomId("cancelar")
                                .setLabel("Cancelar")
                                .setStyle(4)
                                .setEmoji("<a:1150939352503963768:1155318230345322507>")
                            )
                        ]
                    })
                   
                 }
                
                })

                })
            })
        }
    }
})

process.on('unhandRejection', (reason, promise) => {
    console.log(`🚫 Erro Detectado:\n\n` + reason, promise)
  });
  process.on('uncaughtException', (error, origin) => {
    console.log(`🚫 Erro Detectado:\n\n` + error, origin)
  });
