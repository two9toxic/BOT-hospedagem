const { StringSelectMenuBuilder, EmbedBuilder, ActionRowBuilder, ApplicationCommandType, ApplicationCommandOptionType, ButtonBuilder, ComponentType, ModalBuilder, TextInputBuilder } = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const auto = new JsonDatabase({ databasePath:"./jsons/autocomplete.json" });
const db = new JsonDatabase({ databasePath:"./jsons/produtos.json" });
const perms = new JsonDatabase({ databasePath:"./jsons/perms.json" });
const fs = require("fs")
const JSZip = require('jszip');


module.exports = {
    name: "enviarmensagem",
    description:"Veja todos os seus produtos registrados",
    type: ApplicationCommandType.ChatInput, 
    options: [
      {
        name:"configpainel",
        description:"Veja todos os seus produtos registrados",
        type:ApplicationCommandOptionType.String,
        required: true,
      },
    ],

    run: async(client,interaction) => { 
        if(interaction.user.id !== perms.get(`${interaction.user.id}_id`)) {
            return interaction.reply({content:"Você não tem permissão para usar este comando.", ephemeral:true})
        }
        const id = interaction.options.getString("configpainel")
        if(id !== db.get(`${id}.nomeproduto`)) {
            interaction.reply({
                embeds:[
                    new EmbedBuilder()
                    .setDescription(`❌ | Não Achei Nenhum produto com este nome!`)
                    .setColor("Red")
                ],
                ephemeral:true
            })
            return;
        }

        const embed = new EmbedBuilder().setDescription(`${db.get(`${id}.preco.embed.desc`)}`).setTitle(`${db.get(`${id}.preco.embed.titulo`)}`).setColor(`${db.get(`${id}.preco.embed.cor`)}`)

        if(db.get(`${id}.preco.embed.banner`) !== null) {
            embed.setImage(`${db.get(`${id}.preco.embed.banner`)}`)
        }

        interaction.channel.send({
            embeds:[
                embed
            ],
            components:[
                new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setCustomId(`${id}`)
                    .setLabel("Realizar Compra")
                    .setEmoji("🛒")
                    .setStyle(1)
                )
            ]
        }).then(() => {
            interaction.reply({
                content:`✔ ${interaction.user}, sua mensagem foi enviada no chat atual.`,
                ephemeral:true
            })
        }).catch(() => {
            interaction.channel.send({
                embeds:[
                    new EmbedBuilder().setDescription(`${db.get(`${id}.preco.embed.desc`)}`).setTitle(`${db.get(`${id}.preco.embed.titulo`)}`).setColor(`${db.get(`${id}.preco.embed.cor`)}`)
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${id}`)
                        .setLabel("Realizar Compra")
                        .setEmoji("🛒")
                        .setStyle(1)
                    )
                ]
            }).then(() => {
                interaction.reply({
                    content:`✔ ${interaction.user}, sua mensagem foi enviada no chat atual.`,
                    ephemeral:true
                })
            }).catch(() => {
                interaction.reply({
                    content:`❌ ${interaction.user}, Sua mensagem acabou não sendo enviada...`,
                    ephemeral:true
                })
            })
        })

    }}