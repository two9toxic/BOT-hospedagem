const { StringSelectMenuBuilder, EmbedBuilder, ActionRowBuilder, ApplicationCommandType, ApplicationCommandOptionType, ButtonBuilder, ComponentType, ModalBuilder, TextInputBuilder } = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const auto = new JsonDatabase({ databasePath:"./jsons/autocomplete.json" });
const db = new JsonDatabase({ databasePath:"./jsons/produtos.json" });
const perms = new JsonDatabase({ databasePath:"./jsons/perms.json" });
const fs = require("fs")
const JSZip = require('jszip');


module.exports = {
    name: "configpainel",
    description:"Veja todos os seus produtos registrados",
    type: ApplicationCommandType.ChatInput, 
    options: [
      {
        name:"configpainel",
        description:"Veja todos os seus produtos registrados",
        type:ApplicationCommandOptionType.String,
        required: true,
      },
    ],
    run: async(client,interaction) => {
        if(interaction.user.id !== perms.get(`${interaction.user.id}_id`)) {
            return interaction.reply({content:"Você não tem permissão para usar este comando.", ephemeral:true})
        }
        const id = interaction.options.getString("configpainel")
        if(id !== db.get(`${id}.nomeproduto`)) {
            interaction.reply({
                embeds:[
                    new EmbedBuilder()
                    .setDescription(`❌ | Não Achei Nenhum produto com este nome!`)
                    .setColor("Red")
                ],
                ephemeral:true
            })
            return;
        }

       const msg1 = await interaction.reply({
            embeds:[
                new EmbedBuilder()
                .setTitle(`⚙ ${interaction.guild.name} | Configuração painel (${id}) ⚙`)
                .setDescription(`Selecione abaixo qual opção deseja alterar no seu painel. É importante que você preste atenção nas configurações atuais para garantir que suas alterações sejam feitas corretamente. 💥`)
            ],
            components:[
                new ActionRowBuilder()
                .addComponents(
                    new StringSelectMenuBuilder()
                    .addOptions(
                        {
                            label:"Alterar Arquivo Produto",
                            description:"Altere o arquivo do produto",
                            value:"alterar_arquivo_produto_select",
                            emoji:"⬆"
                        },
                        {
                            label:"Alterar Preço Produto",
                            description:"Altere o preço da venda",
                            value:"alterar_preço_venda_select",
                            emoji:"⬆"
                        },
                        {
                            label:"Configurar EMBED (OPCIONAL)",
                            description:"Alterar Todas opções do embed de vendas",
                            value:"alterar_embed_select",
                            emoji:"<:4323blurpleverifiedbotdeveloper:1178363017096876113>"
                        },
                        {
                            label:"Deletar Produto",
                            description:"Delete este produto",
                            value:"delete_product_select",
                            emoji:"<:a_negativo_cupula:1178452417080205454>"
                        },

                    )
                    .setCustomId("configpainel_select")
                    .setPlaceholder("Selecione abaixo qual Configurações Avançadas deseja alterar")
                    .setMaxValues(1)
                )
            ]
        })
        const user = interaction.user
        const interação = msg1.createMessageComponentCollector({ componentType: ComponentType.StringSelect });
        interação.on("collect", async (interaction) => {
         if (user.id !== interaction.user.id) {
            interaction.deferUpdate()
           return;
         }

         if(interaction.customId === "configpainel_select") {
            const options = interaction.values[0]
            if(options === "alterar_arquivo_produto_select") {
                  interaction.update({
                    embeds:[
                        new EmbedBuilder()
                        .setTitle(`⚙ ${interaction.guild.name} | Configuração Arquivo (${id}) ⚙`)
                        .setDescription(`💥 Envie abaixo o NOVO arquivo que deseja entregar na hora do aprovamento do pagamento.`)
                    ],
                    components:[]
                  })
    const collector = interaction.channel.createMessageCollector({
        filter: m => m.attachments.first() && m.attachments.first().name.endsWith('.zip'),
        max: 1,
    });
    

    collector.on('collect', async (message) => {
        if(message.author.id !== interaction.user.id) return;
        const attachment = message.attachments.first();
        const zip = new JSZip();
        
        
        const data = await fetch(attachment.url).then(res => res.arrayBuffer());
        const zipFile = await zip.loadAsync(data);

        interaction.message.edit({
            embeds:[
                new EmbedBuilder()
                .setTitle(`⚙ ${interaction.guild.name} | Configurações Avançadas ⚙`)
                .setDescription(`✔ Estamos Verificando os arquivos enviados.`)
            ],
            components:[]
        })
        message.delete()
        if (zipFile.files['package.json'] && (zipFile.files['squarecloud.config'] || zipFile.files['squarecloud.app'])) {
            const packageJson = JSON.parse(await zipFile.file('package.json').async('string'));

            
            zipFile.file('package.json', JSON.stringify(packageJson));

            
            const dir = './source';
            if (!fs.existsSync(dir)){
                fs.mkdirSync(dir);
            }
            fs.writeFileSync(`${dir}/${id}.zip`, await zipFile.generateAsync({type:"nodebuffer"}))

            interaction.message.edit({
                embeds:[
                    new EmbedBuilder()
                    .setTitle(`⚙ ${interaction.guild.name} | Configurações Avançadas ⚙`)
                    .setDescription(`Gostaria de informar que o produto **${id}** teve seu arquivo de entrega alterado.`)
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId("volatasd")
                        .setLabel("Voltar")
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                        .setStyle(2)
                    )
                ]
            })
            
            
        } else {
            interaction.message.edit({
                embeds:[
                    new Discord.EmbedBuilder()
                    .setTitle(`⚙ ${interaction.guild.name} | Configurações Avançadas ⚙`)
                    .setDescription(`Não Gostaria de informar que o produto (BOT) de **${id}** Está com algum problema. Verifique se o BOT tenha package.json ou squarecloud.app/squarecloud.config`)
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId("voltar2")
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                    )
                ]
            })
        }
    });
            }
            if(options === "alterar_preço_venda_select") {
                interaction.update({
                    embeds:[
                        new EmbedBuilder()
                        .setTitle(`⚙ ${interaction.guild.name} | Configuração PREÇO (${id}) ⚙`)
                        .setDescription(`💥 Selecione abaixo qual o button para escolher o valor de (MENSALIDADE / QUINZENA / SEMANAL).`)
                    ],
                    components:[
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("alterarmensalidade30")
                            .setLabel("Alterar Mensalidade (30 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarquinzena15")
                            .setLabel("Alterar Quinzena (15 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarsemanal7")
                            .setLabel("Alterar Semanal (7 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("ativ_des_mensal") 
                            .setLabel(`${db.get(`${id}.preco.mensal.onoff`) === true ? "Desativar Mensalidade (30 DIAS)" : "Ativar Mensalidade (30 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_quinzena") 
                            .setLabel(`${db.get(`${id}.preco.quizena.onoff`) === true ? "Desativar Quinzena (15 DIAS)" : "Ativar Quinzena (15 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_semanal") 
                            .setLabel(`${db.get(`${id}.preco.semanal.onoff`) === true ? "Desativar Semanal (7 DIAS)" : "Ativar Semanal (7 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                        new ButtonBuilder()
                        .setCustomId("volatasd")
                        .setLabel("Voltar")
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                        .setStyle(2)
                        )
                    ]
                })
            }
            if(options === "alterar_embed_select") {
                interaction.update({
                    embeds:[
                        new EmbedBuilder()
                        .setTitle(`⚙ ${interaction.guild.name} | Configuração EMBED (${id}) ⚙`)
                        .setDescription(`💥 Selecione abaixo qual opção do EMBED deseja alterar do seu produto.`)
                    ],
                    components:[
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("alterar_cor_embed_product")
                            .setStyle(2)
                            .setLabel("Alterar Cor")
                            .setEmoji("<:Caixa334lunnarsss:1127234012008697926>"),
                            new ButtonBuilder()
                            .setCustomId("alterar_titulo_embed_product")
                            .setStyle(2)
                            .setLabel("Alterar Titulo")
                            .setEmoji("<:Caixa334lunnarsss:1127234012008697926>"),
                            new ButtonBuilder()
                            .setCustomId("alterar_desc_embed_product")
                            .setStyle(2)
                            .setLabel("Alterar Descrição")
                            .setEmoji("<:Caixa334lunnarsss:1127234012008697926>"),
                            new ButtonBuilder()
                            .setCustomId("alterar_banner_embed_product")
                            .setStyle(2)
                            .setLabel("Alterar Banner")
                            .setEmoji("<:Caixa334lunnarsss:1127234012008697926>"),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                        new ButtonBuilder()
                        .setCustomId("volatasd")
                        .setLabel("Voltar")
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                        .setStyle(2)
                        )

                    ]
                })
            }
            if(options === "delete_product_select") {
                fs.unlink(`source/${id}.zip`, (err) => {
                    if (err) {
                      interaction.reply({
                        embeds:[
                            new EmbedBuilder()
                            .setDescription(`❌ | Ocorreu um erro ao tentar excluir o produto`)
                        ]
                      })
                    } else {

                      interaction.message.delete()
                      db.delete(`${id}`)
                      let dados = auto.get(`produtos`)
                      dados = dados.filter(produto => produto !== `${id}`)
                      auto.set(`produto`, dados);

                    }
                  });
            }
         }

         
         client.on("interactionCreate", async( interaction) => {

            
            if(interaction.isButton() && interaction.customId === "alterar_banner_embed_product") {
                const modal = new ModalBuilder()
                .setCustomId("embed_banner_url_modal")
                .setTitle("Alterar banner");
                const text = new TextInputBuilder()
                .setCustomId("text")
                .setLabel("Qual será o novo banner?")
                .setStyle(1)
                .setPlaceholder("Coloque URL")
                .setRequired(true)

                modal.addComponents(new ActionRowBuilder().addComponents(text))

                await interaction.showModal(modal)
            }

            if(interaction.isModalSubmit() && interaction.customId === "embed_banner_url_modal") {
                const text = interaction.fields.getTextInputValue("text")
                await db.set(`${id}.preco.embed.banner`, text)

                interaction.reply({
                    embeds:[ 
                        new EmbedBuilder()
                        .setDescription(`✅ | Alterado com sucesso!`)
                    ],
                    ephemeral:true
                })

            }



            
            if(interaction.isButton() && interaction.customId === "alterar_desc_embed_product") {
                const modal = new ModalBuilder()
                .setCustomId("embed_desc_modal")
                .setTitle("Alterar Descrição");
                const text = new TextInputBuilder()
                .setCustomId("text")
                .setLabel("Qual será a Nova Descrição?")
                .setStyle(2)
                .setRequired(true)

                modal.addComponents(new ActionRowBuilder().addComponents(text))

                await interaction.showModal(modal)
            }

            if(interaction.isModalSubmit() && interaction.customId === "embed_desc_modal") {
                const text = interaction.fields.getTextInputValue("text")
                await db.set(`${id}.preco.embed.desc`, text)

                interaction.reply({
                    embeds:[ 
                        new EmbedBuilder()
                        .setDescription(`✅ | Alterado com sucesso!`)
                    ],
                    ephemeral:true
                })

            }



            
            if(interaction.isButton() && interaction.customId === "alterar_titulo_embed_product") {
                const modal = new ModalBuilder()
                .setCustomId("embed_titulo_modal")
                .setTitle("Alterar Titulo");
                const text = new TextInputBuilder()
                .setCustomId("text")
                .setLabel("Qual será o novo titulo?")
                .setStyle(1)
                .setRequired(true)

                modal.addComponents(new ActionRowBuilder().addComponents(text))

                await interaction.showModal(modal)
            }

            if(interaction.isModalSubmit() && interaction.customId === "embed_titulo_modal") {
                const text = interaction.fields.getTextInputValue("text")
                await db.set(`${id}.preco.embed.titulo`, text)

                interaction.reply({
                    embeds:[ 
                        new EmbedBuilder()
                        .setDescription(`✅ | Alterado com sucesso!`)
                    ],
                    ephemeral:true
                })

            }


            if(interaction.isButton() && interaction.customId === "alterar_cor_embed_product") {
                const modal = new ModalBuilder()
                .setCustomId("embed_color_hex_modal")
                .setTitle("Alterar Cor da Embed");
                const text = new TextInputBuilder()
                .setCustomId("text")
                .setLabel("Coloque a cor em hexadecimal!")
                .setStyle(1)
                .setRequired(true)

                modal.addComponents(new ActionRowBuilder().addComponents(text))

                await interaction.showModal(modal)
            }
            if(interaction.isModalSubmit() && interaction.customId === "embed_color_hex_modal") {
                const text = interaction.fields.getTextInputValue("text")
                function isValidHexColor(hexColor) {
                    return /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(hexColor);
                }

                if(!isValidHexColor(text)) {
                    interaction.reply({
                        embeds:[
                            new EmbedBuilder()
                            .setDescription("❌ | Coloque um valor hexadecimal Verdadeiro!")
                        ],
                        ephemeral:true
                    })
                    return;
                }
                await db.set(`${id}.preco.embed.cor`, text)

                interaction.reply({
                    embeds:[ 
                        new EmbedBuilder()
                        .setDescription(`✅ | Alterado com sucesso!`)
                    ],
                    ephemeral:true
                })

            }
            if(interaction.isButton() && interaction.customId === "ativ_des_semanal") {
                if(await db.get(`${id}.preco.semanal.onoff`) === true) {

                    await db.set(`${id}.preco.semanal.onoff`, false)

                } else {

                    await db.set(`${id}.preco.semanal.onoff`, true)

                }
                interaction.update({
                    components:[
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("alterarmensalidade30")
                            .setLabel("Alterar Mensalidade (30 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarquinzena15")
                            .setLabel("Alterar Quinzena (15 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarsemanal7")
                            .setLabel("Alterar Semanal (7 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("ativ_des_mensal") 
                            .setLabel(`${db.get(`${id}.preco.mensal.onoff`) === true ? "Desativar Mensalidade (30 DIAS)" : "Ativar Mensalidade (30 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_quinzena") 
                            .setLabel(`${db.get(`${id}.preco.quizena.onoff`) === true ? "Desativar Quinzena (15 DIAS)" : "Ativar Quinzena (15 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_semanal") 
                            .setLabel(`${db.get(`${id}.preco.semanal.onoff`) === true ? "Desativar Semanal (7 DIAS)" : "Ativar Semanal (7 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                        new ButtonBuilder()
                        .setCustomId("volatasd")
                        .setLabel("Voltar")
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                        .setStyle(2)
                        )
                    ]
                })
            }

            


            if(interaction.isButton() && interaction.customId === "ativ_des_quinzena") {
                if(await db.get(`${id}.preco.quizena.onoff`) === true) {

                    await db.set(`${id}.preco.quizena.onoff`, false)

                } else {

                    await db.set(`${id}.preco.quizena.onoff`, true)

                }
                interaction.update({
                    components:[
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("alterarmensalidade30")
                            .setLabel("Alterar Mensalidade (30 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarquinzena15")
                            .setLabel("Alterar Quinzena (15 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarsemanal7")
                            .setLabel("Alterar Semanal (7 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("ativ_des_mensal") 
                            .setLabel(`${db.get(`${id}.preco.mensal.onoff`) === true ? "Desativar Mensalidade (30 DIAS)" : "Ativar Mensalidade (30 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_quinzena") 
                            .setLabel(`${db.get(`${id}.preco.quizena.onoff`) === true ? "Desativar Quinzena (15 DIAS)" : "Ativar Quinzena (15 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_semanal") 
                            .setLabel(`${db.get(`${id}.preco.semanal.onoff`) === true ? "Desativar Semanal (7 DIAS)" : "Ativar Semanal (7 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                        new ButtonBuilder()
                        .setCustomId("volatasd")
                        .setLabel("Voltar")
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                        .setStyle(2)
                        )
                    ]
                })
            }

            
            if(interaction.isButton() && interaction.customId === "ativ_des_mensal") {
                if(await db.get(`${id}.preco.mensal.onoff`) === true) {

                    await db.set(`${id}.preco.mensal.onoff`, false)

                } else {

                    await db.set(`${id}.preco.mensal.onoff`, true)

                }
                interaction.update({
                    components:[
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("alterarmensalidade30")
                            .setLabel("Alterar Mensalidade (30 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarquinzena15")
                            .setLabel("Alterar Quinzena (15 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarsemanal7")
                            .setLabel("Alterar Semanal (7 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("ativ_des_mensal") 
                            .setLabel(`${db.get(`${id}.preco.mensal.onoff`) === true ? "Desativar Mensalidade (30 DIAS)" : "Ativar Mensalidade (30 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_quinzena") 
                            .setLabel(`${db.get(`${id}.preco.quizena.onoff`) === true ? "Desativar Quinzena (15 DIAS)" : "Ativar Quinzena (15 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_semanal") 
                            .setLabel(`${db.get(`${id}.preco.semanal.onoff`) === true ? "Desativar Semanal (7 DIAS)" : "Ativar Semanal (7 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                        new ButtonBuilder()
                        .setCustomId("volatasd")
                        .setLabel("Voltar")
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                        .setStyle(2)
                        )
                    ]
                })
            }

            
            if(interaction.isButton() && interaction.customId === "alterarsemanal7") {
                const modal = new ModalBuilder()
                .setCustomId("modalsemanal_7")
                .setTitle(`${id} - valorsemanal`)

                const text = new TextInputBuilder()
                .setLabel("Preço do Produto.")
                .setRequired(true)
                .setStyle(1)
                .setPlaceholder("Apenas numeros: exemplo: 0.10 / 1.10 / 2")
                .setCustomId("text")

                modal.addComponents(new ActionRowBuilder().addComponents(text))
                await interaction.showModal(modal)
            }
            if(interaction.isModalSubmit() && interaction.customId === "modalsemanal_7") {
                const text = interaction.fields.getTextInputValue("text")
                if(isNaN(text)) {
                    interaction.reply({
                        embeds:[
                            new EmbedBuilder()
                            .setDescription(`❌ | Você Não colocou numeros!`)
                        ],
                        ephemeral:true
                    })
                    return;
                }
                let number = Number(text);
                number = Math.round(number * 100) / 100;
                await db.set(`${id}.preco.semanal.preco`, number)


                interaction.update({
                    embeds:[
                        new EmbedBuilder()
                        .setTitle(`⚙ ${interaction.guild.name} | Configuração PREÇO (${id}) ⚙`)
                        .setDescription(`✔ O produto **${id}** teve seu valor **valorsemanal** alterado para ${text}.`)
                    ],
                    components:[
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("alterarmensalidade30")
                            .setLabel("Alterar Mensalidade (30 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarquinzena15")
                            .setLabel("Alterar Quinzena (15 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarsemanal7")
                            .setLabel("Alterar Semanal (7 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("ativ_des_mensal") 
                            .setLabel(`${db.get(`${id}.preco.mensal.onoff`) === true ? "Desativar Mensalidade (30 DIAS)" : "Ativar Mensalidade (30 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_quinzena") 
                            .setLabel(`${db.get(`${id}.preco.quizena.onoff`) === true ? "Desativar Quinzena (15 DIAS)" : "Ativar Quinzena (15 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_semanal") 
                            .setLabel(`${db.get(`${id}.preco.semanal.onoff`) === true ? "Desativar Semanal (7 DIAS)" : "Ativar Semanal (7 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                        new ButtonBuilder()
                        .setCustomId("volatasd")
                        .setLabel("Voltar")
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                        .setStyle(2)
                        )
                    ]
                })

            }
            if(interaction.isButton() && interaction.customId === "alterarquinzena15") {
                const modal = new ModalBuilder()
                .setCustomId("modalquinzena_15")
                .setTitle(`${id} - valorquinzena`)

                const text = new TextInputBuilder()
                .setLabel("Preço do Produto.")
                .setRequired(true)
                .setStyle(1)
                .setPlaceholder("Apenas numeros: exemplo: 0.10 / 1.10 / 2")
                .setCustomId("text")

                modal.addComponents(new ActionRowBuilder().addComponents(text))
                await interaction.showModal(modal)
            }

            
            if(interaction.isModalSubmit() && interaction.customId === "modalquinzena_15") {
                const text = interaction.fields.getTextInputValue("text")
                if(isNaN(text)) {
                    interaction.reply({
                        embeds:[
                            new EmbedBuilder()
                            .setDescription(`❌ | Você Não colocou numeros!`)
                        ],
                        ephemeral:true
                    })
                    return;
                }
                let number = Number(text);
                number = Math.round(number * 100) / 100;
                await db.set(`${id}.preco.quizena.preco`, number)

                interaction.update({
                    embeds:[
                        new EmbedBuilder()
                        .setTitle(`⚙ ${interaction.guild.name} | Configuração PREÇO (${id}) ⚙`)
                        .setDescription(`✔ O produto **${id}** teve seu valor **valorquinzena** alterado para ${text}.`)
                    ],
                    components:[
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("alterarmensalidade30")
                            .setLabel("Alterar Mensalidade (30 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarquinzena15")
                            .setLabel("Alterar Quinzena (15 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarsemanal7")
                            .setLabel("Alterar Semanal (7 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("ativ_des_mensal") 
                            .setLabel(`${db.get(`${id}.preco.mensal.onoff`) === true ? "Desativar Mensalidade (30 DIAS)" : "Ativar Mensalidade (30 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_quinzena") 
                            .setLabel(`${db.get(`${id}.preco.quizena.onoff`) === true ? "Desativar Quinzena (15 DIAS)" : "Ativar Quinzena (15 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_semanal") 
                            .setLabel(`${db.get(`${id}.preco.semanal.onoff`) === true ? "Desativar Semanal (7 DIAS)" : "Ativar Semanal (7 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                        new ButtonBuilder()
                        .setCustomId("volatasd")
                        .setLabel("Voltar")
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                        .setStyle(2)
                        )
                    ]
                })

            }

            if(interaction.isButton() && interaction.customId === "alterarmensalidade30") {
                const modal = new ModalBuilder()
                .setCustomId("modalmensalidade_30")
                .setTitle(`${id} - valormensal`)

                const text = new TextInputBuilder()
                .setLabel("Preço do Produto.")
                .setRequired(true)
                .setStyle(1)
                .setPlaceholder("Apenas numeros: exemplo: 0.10 / 1.10 / 2")
                .setCustomId("text")

                modal.addComponents(new ActionRowBuilder().addComponents(text))
                await interaction.showModal(modal)
            }

            
            if(interaction.isModalSubmit() && interaction.customId === "modalmensalidade_30") {
                const text = interaction.fields.getTextInputValue("text")
                if(isNaN(text)) {
                    interaction.reply({
                        embeds:[
                            new EmbedBuilder()
                            .setDescription(`❌ | Você Não colocou numeros!`)
                        ],
                        ephemeral:true
                    })
                    return;
                }
                let number = Number(text);
                number = Math.round(number * 100) / 100;
                await db.set(`${id}.preco.mensal.preco`, number)

                interaction.update({
                    embeds:[
                        new EmbedBuilder()
                        .setTitle(`⚙ ${interaction.guild.name} | Configuração PREÇO (${id}) ⚙`)
                        .setDescription(`✔ O produto **${id}** teve seu valor **valormensal** alterado para ${text}.`)
                    ],
                    components:[
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("alterarmensalidade30")
                            .setLabel("Alterar Mensalidade (30 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarquinzena15")
                            .setLabel("Alterar Quinzena (15 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("alterarsemanal7")
                            .setLabel("Alterar Semanal (7 DIAS)")
                            .setEmoji("<:money:1095550948765610135>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                            .setCustomId("ativ_des_mensal") 
                            .setLabel(`${db.get(`${id}.preco.mensal.onoff`) === true ? "Desativar Mensalidade (30 DIAS)" : "Ativar Mensalidade (30 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_quinzena") 
                            .setLabel(`${db.get(`${id}.preco.quizena.onoff`) === true ? "Desativar Quinzena (15 DIAS)" : "Ativar Quinzena (15 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                            new ButtonBuilder()
                            .setCustomId("ativ_des_semanal") 
                            .setLabel(`${db.get(`${id}.preco.semanal.onoff`) === true ? "Desativar Semanal (7 DIAS)" : "Ativar Semanal (7 DIAS)"}`)
                            .setEmoji("<:7235bot:1178512292619505735>")
                            .setStyle(2),
                        ),
                        new ActionRowBuilder()
                        .addComponents(
                        new ButtonBuilder()
                        .setCustomId("volatasd")
                        .setLabel("Voltar")
                        .setEmoji("<:voltarkauan:1177188031179010119>")
                        .setStyle(2)
                        )
                    ]
                })

            }

            
            if(interaction.isButton() && interaction.customId === "volatasd") {
                interaction.update({
                    embeds:[
                        new EmbedBuilder()
                        .setTitle(`⚙ ${interaction.guild.name} | Configuração painel (${id}) ⚙`)
                        .setDescription(`Selecione abaixo qual opção deseja alterar no seu painel. É importante que você preste atenção nas configurações atuais para garantir que suas alterações sejam feitas corretamente. 💥`)
                    ],
                    components:[
                        new ActionRowBuilder()
                        .addComponents(
                            new StringSelectMenuBuilder()
                            .addOptions(
                                {
                                    label:"Alterar Arquivo Produto",
                                    description:"Altere o arquivo do produto",
                                    value:"alterar_arquivo_produto_select",
                                    emoji:"⬆"
                                },
                                {
                                    label:"Alterar Preço Produto",
                                    description:"Altere o preço da venda",
                                    value:"alterar_preço_venda_select",
                                    emoji:"⬆"
                                },
                                {
                                    label:"Configurar EMBED (OPCIONAL)",
                                    description:"Alterar Todas opções do embed de vendas",
                                    value:"alterar_embed_select",
                                    emoji:"<:4323blurpleverifiedbotdeveloper:1178363017096876113>"
                                },
                                {
                                    label:"Deletar Produto",
                                    description:"Delete este produto",
                                    value:"delete_product_select",
                                    emoji:"<:a_negativo_cupula:1178452417080205454>"
                                },
        
                            )
                            .setCustomId("configpainel_select")
                            .setPlaceholder("Selecione abaixo qual Configurações Avançadas deseja alterar")
                            .setMaxValues(1)
                        )
                    ]
                })
            }
         })
        
        })
        
    }}
    